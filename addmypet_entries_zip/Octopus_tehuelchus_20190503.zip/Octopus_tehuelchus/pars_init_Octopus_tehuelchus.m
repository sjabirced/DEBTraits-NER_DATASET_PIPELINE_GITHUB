function [par, metaPar, txtPar] = pars_init_Octopus_tehuelchus(metaData)

metaPar.model = 'abj'; 

%% reference parameter (not to be changed) 
par.T_ref = 293.15;   free.T_ref = 0;   units.T_ref = 'K';        label.T_ref = 'Reference temperature'; 

%% core primary parameters 
par.T_A = 11000;      free.T_A   = 0;   units.T_A = 'K';          label.T_A = 'Arrhenius temperature'; 
par.z = 1.3266;       free.z     = 1;   units.z = '-';            label.z = 'zoom factor'; 
par.F_m = 6.5;        free.F_m   = 0;   units.F_m = 'l/d.cm^2';   label.F_m = '{F_m}, max spec searching rate'; 
par.kap_X = 0.8;      free.kap_X = 0;   units.kap_X = '-';        label.kap_X = 'digestion efficiency of food to reserve'; 
par.kap_P = 0.1;      free.kap_P = 0;   units.kap_P = '-';        label.kap_P = 'faecation efficiency of food to faeces'; 
par.v = 0.01914;      free.v     = 1;   units.v = 'cm/d';         label.v = 'energy conductance'; 
par.kap = 0.98346;    free.kap   = 1;   units.kap = '-';          label.kap = 'allocation fraction to soma'; 
par.kap_R = 0.95;     free.kap_R = 0;   units.kap_R = '-';        label.kap_R = 'reproduction efficiency'; 
par.p_M = 110.2626;   free.p_M   = 1;   units.p_M = 'J/d.cm^3';   label.p_M = '[p_M], vol-spec somatic maint'; 
par.p_T = 0;          free.p_T   = 0;   units.p_T = 'J/d.cm^2';   label.p_T = '{p_T}, surf-spec somatic maint'; 
par.k_J = 0.002;      free.k_J   = 0;   units.k_J = '1/d';        label.k_J = 'maturity maint rate coefficient'; 
par.E_G = 5640.199;   free.E_G   = 1;   units.E_G = 'J/cm^3';     label.E_G = '[E_G], spec cost for structure'; 
par.E_Hb = 1.404e-01; free.E_Hb  = 1;   units.E_Hb = 'J';         label.E_Hb = 'maturity at birth'; 
par.E_Hj = 1.851e+01; free.E_Hj  = 1;   units.E_Hj = 'J';         label.E_Hj = 'maturity at metam'; 
par.E_Hp = 2.694e+02; free.E_Hp  = 1;   units.E_Hp = 'J';         label.E_Hp = 'maturity at puberty'; 
par.h_a = 4.267e-25;  free.h_a   = 1;   units.h_a = '1/d^2';      label.h_a = 'Weibull aging acceleration'; 
par.s_G = 1;          free.s_G   = 0;   units.s_G = '-';          label.s_G = 'Gompertz stress coefficient'; 

%% other parameters 
par.del_M = 0.46103;  free.del_M = 1;   units.del_M = '-';        label.del_M = 'shape coefficient'; 
par.f = 1;            free.f     = 0;   units.f = '-';            label.f = 'scaled functional response for 0-var data'; 
par.f_B000 = 0.45789;  free.f_B000 = 1;   units.f_B000 = '-';       label.f_B000 = 'scaled functional response for tL_B data at t=000 d'; 
par.f_B060 = 0.52218;  free.f_B060 = 1;   units.f_B060 = '-';       label.f_B060 = 'scaled functional response for tL_B data at t=060 d'; 
par.f_B120 = 0.8437;  free.f_B120 = 1;   units.f_B120 = '-';       label.f_B120 = 'scaled functional response for tL_B data at t=120 d'; 
par.f_B140 = 4.4039e-05;  free.f_B140 = 1;   units.f_B140 = '-';       label.f_B140 = 'scaled functional response for tL_B data at t=140 d'; 
par.f_B220 = 0.00012389;  free.f_B220 = 1;   units.f_B220 = '-';       label.f_B220 = 'scaled functional response for tL_B data at t=220 d'; 
par.f_B240 = 1.0545;  free.f_B240 = 1;   units.f_B240 = '-';       label.f_B240 = 'scaled functional response for tL_B data at t=240 d'; 
par.f_B300 = 1.0827;  free.f_B300 = 1;   units.f_B300 = '-';       label.f_B300 = 'scaled functional response for tL_B data at t=300 d'; 
par.f_E000 = 1.0778;  free.f_E000 = 1;   units.f_E000 = '-';       label.f_E000 = 'scaled functional response for tL_E data at t=000 d'; 
par.f_E060 = 0.86475;  free.f_E060 = 1;   units.f_E060 = '-';       label.f_E060 = 'scaled functional response for tL_E data at t=060 d'; 
par.f_E120 = 0.64154;  free.f_E120 = 1;   units.f_E120 = '-';       label.f_E120 = 'scaled functional response for tL_E data at t=120 d'; 
par.f_E180 = 0.29068;  free.f_E180 = 1;   units.f_E180 = '-';       label.f_E180 = 'scaled functional response for tL_E data at t=180 d'; 
par.f_E240 = 0.10571;  free.f_E240 = 1;   units.f_E240 = '-';       label.f_E240 = 'scaled functional response for tL_E data at t=240 d'; 
par.f_E300 = 0.85804;  free.f_E300 = 1;   units.f_E300 = '-';       label.f_E300 = 'scaled functional response for tL_E data at t=300 d'; 
par.f_I000 = 1.1322;  free.f_I000 = 1;   units.f_I000 = '-';       label.f_I000 = 'scaled functional response for tL_I data at t=000 d'; 
par.f_I060 = 0.64985;  free.f_I060 = 1;   units.f_I060 = '-';       label.f_I060 = 'scaled functional response for tL_I data at t=060 d'; 
par.f_I120 = 0.0024741;  free.f_I120 = 1;   units.f_I120 = '-';       label.f_I120 = 'scaled functional response for tL_I data at t=120 d'; 
par.f_I180 = 0.0092292;  free.f_I180 = 1;   units.f_I180 = '-';       label.f_I180 = 'scaled functional response for tL_I data at t=180 d'; 
par.f_I240 = 1.051;   free.f_I240 = 1;   units.f_I240 = '-';       label.f_I240 = 'scaled functional response for tL_I data at t=240 d'; 
par.f_I300 = 0.93748;  free.f_I300 = 1;   units.f_I300 = '-';       label.f_I300 = 'scaled functional response for tL_I data at t=300 d'; 
par.z_m = 1.2046;     free.z_m   = 1;   units.z_m = '-';          label.z_m = 'zoom factor for males'; 

%% set chemical parameters from Kooy2010 
[par, units, label, free] = addchem(par, units, label, free, metaData.phylum, metaData.class); 

%% Pack output: 
txtPar.units = units; txtPar.label = label; par.free = free; 
