function [prdData, info] = predict_Salamandra_lanzai(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);

  % compute temperature correction factors
  TC = tempcorr(temp.am, T_ref, T_A); kT_M = TC * k_M;
  TC_tj = tempcorr(temp.tj, T_ref, T_A);
  
% zero-variate data

  % life cycle
  pars_tj = [g; k; l_T; v_Hb; v_Hj];               % compose parameter vector
  [t_j, t_b, l_j, l_b, info] = get_tp(pars_tj, f); % -, scaled times & lengths at f
  pars_tp = [g; k; l_T; v_Hb; v_Hp];               % compose parameter vector
  [t_p, t_b, l_p, l_b, info] = get_tp(pars_tp, f); % -, scaled times & lengths at f
  
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Lw_b = L_b/ del_M;                % cm, physical length at birth at f
  Ww_b = L_b^3 * (1 + f * w);       % g, wet weight at birth
  aT_b = t_b/ kT_M;                 % d, age at birth
  
  % metam
  L_j = L_m * l_j;                  % cm, structural length at metam at f
  Lw_j = L_j/ del_M;                % cm, physical length at metam at f
  Ww_j = L_j^3 * (1 + f * w);       % g, wet weight at metam
  tT_j = (t_j - t_b)/ k_M/ TC_tj;   % d, time since birth at metam
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Lw_p = L_p/ del_M;                % cm, physical length at puberty at f
  Ww_p = L_p^3 * (1 + f * w);       % g, wet weight at puberty
  tT_p = (t_p - t_b)/ kT_M;         % d, age at puberty at f and T

  % ultimate
  l_i = f - l_T;                    % -, scaled ultimate length
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate physical length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 

  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
  RT_i = TC *  reprod_rate((25.5/(1 + f * w))^(1/3), f, pars_R);% #/d, reprod rate at 25.5 g

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC;                  % d, mean life span at T
  
  % males
  p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
  E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
  g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
  m_Em_m = y_E_V * E_m_m/ E_G;         % mol/mol, reserve capacity 
  w_m = m_Em_m * w_E/ w_V;             % -, contribution of reserve to weight
  L_mm = v/ k_M/ g_m;                  % cm, max struct length
  pars_tjm = [g_m; k; l_T; v_Hb; v_Hj];             % compose parameter vector
  [t_jm, t_bm, l_jm, l_bm] = get_tp(pars_tjm, f); % -, scaled times & lengths at f
  pars_tpm = [g_m; k; l_T; v_Hb; v_Hpm];               % compose parameter vector
  [t_pm, t_bm, l_pm, l_bm] = get_tp(pars_tpm, f); % -, scaled times & lengths at f
  L_bm = l_bm * L_mm;                  % cm, struct length at birth
  tT_pm = (t_pm - t_bm)/ k_M/ TC;      % time since birth at puberty
  L_pm = l_pm * L_mm; Lw_pm = L_pm/ del_M;% cm, struct length, SVL at puberty
  Ww_pm = L_pm^3 * (1 + f * w_m);      % g, wet weight at puberty
  L_im = f * L_mm; Lw_im = L_im/ del_M;% cm, struct length, SVL
  Ww_im = L_im^3 * (1 + f * w_m);      % g, ultimate wet weight

  % pack to output
  prdData.ab = aT_b;
  prdData.tj = tT_j;
  prdData.tp = tT_p;
  prdData.tpm = tT_pm;
  prdData.am = aT_m;
  prdData.Lb = Lw_b;
  prdData.Lj = Lw_j;
  prdData.Lp = Lw_p;
  prdData.Lpm = Lw_pm;
  prdData.Li = Lw_i;
  prdData.Lim = Lw_im;
  prdData.Wwb = Ww_b;
  prdData.Wwj = Ww_j;
  prdData.Wwp = Ww_p;
  prdData.Wwpm = Ww_pm;
  prdData.Wwi = Ww_i;
  prdData.Wwim = Ww_im;
  prdData.Ri = RT_i;
  
  % univariate data
  % time-length
  % female e
  [tvel, t_p, t_b, l_p, l_b] = get_tp(pars_tp, f_tLw, [], tL_fw(:,1)*kT_M);
  ELw_fw = L_m * tvel(:,4)/ del_M;   % cm, length 
  % male e
  tvel = get_tpm(pars_tpm, f_tLw, [t_b, f_tLw*z/z_m, l_b*z/z_m], tL_mw(:,1)*kT_M);
  ELw_mw = L_mm * tvel(:,4)/ del_M;   % cm, length 
  % female w
  [tvel, t_p, t_b, l_p, l_b] = get_tp(pars_tp, f_tLe, [], tL_fe(:,1)*kT_M);
  ELw_fe = L_m * tvel(:,4)/ del_M;   % cm, length 
  % male w
  tvel = get_tpm(pars_tpm, f_tLe, [t_b, f_tLe*z/z_m, l_b*z/z_m], tL_me(:,1)*kT_M);
  ELw_me = L_mm * tvel(:,4)/ del_M;   % cm, length 

  % pack to output
  prdData.tL_fw = ELw_fw;
  prdData.tL_mw = ELw_mw;
  prdData.tL_fe = ELw_fe;
  prdData.tL_me = ELw_me;

  