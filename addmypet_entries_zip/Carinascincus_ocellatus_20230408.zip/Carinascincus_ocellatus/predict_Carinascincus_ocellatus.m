function [prdData, info] = predict_Carinascincus_ocellatus(par, data, auxData)

% unpack par, data, auxData
cPar = parscomp_st(par); vars_pull(par); 
vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);

%% compute temperature correction factors
TC = tempcorr(temp.am, T_ref, T_A); kT_M = TC * k_M;
TC_tL = tempcorr(temp.tL_f, T_ref, T_A);
TC_tL1 = tempcorr(temp.tL1_f, T_ref, T_A);

% life cycle
pars_tp = [g; k; l_T; v_Hb; v_Hp];               % compose parameter vector
[t_p, t_b, l_p, l_b, info] = get_tp(pars_tp, f); % -, scaled times & lengths at f

% birth
L_b = L_m * l_b;                  % cm, structural length at birth at f
Lw_b = L_b/ del_M;                % cm, physical length at birth at f
Ww_b = L_b^3 * (1 + f * w); % g, dry weight at birth at f (remove d_V for wet weight)
aT_b = t_b/ kT_M;                 % d, age at birth at f and T

% puberty
L_p = L_m * l_p;                  % cm, structural length at puberty at f
Lw_p = L_p/ del_M;                % cm, physical length at puberty at f
Ww_p = L_p^3 * (1 + f * w);       % g, weight at puberty 
tT_p = (t_p-t_b)/ kT_M;           % d, time since birth at puberty at f and T

% ultimate
l_i = f - l_T;                    % -, scaled ultimate length at f
L_i = L_m * l_i;                  % cm, ultimate structural length at f
Lw_i = L_i/ del_M;                % cm, ultimate physical length at f
Ww_i = L_i^3 * (1 + f * w); % g, ultimate dry weight (remove d_V for wet weight)

% reproduction
pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
RT_i = TC * reprod_rate(L_i, f, pars_R);                % #/d, ultimate reproduction rate at T

% life span
pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
aT_m = t_m/ kT_M;                     % d, mean life span at T

% males
p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
m_Em_m = y_E_V * E_m_m/ E_G;         % mol/mol, reserve capacity 
w_m = m_Em_m * w_E/ w_V;             % -, contribution of reserve to weight
L_mm = v/ k_M/ g_m;                  % cm, max struct length
L_bm = l_b * L_mm; L_im = f * L_mm;  % cm, struct length, birth & ultimate
Ww_im = L_im^3 * (1 + f * w_m);      % g, ultimate wet weight
Lw_im = L_im/ del_M;                 % cm, ultimate SVL
pars_tpm = [g_m k l_T v_Hb v_Hp];
Lw_pm = L_mm * get_lp(pars_tpm, f)/ del_M; % cm, SVL at puberty

%% pack to output
% the names of the fields in the structure must be the same as the data names in the mydata file
prdData.ab = aT_b;
prdData.am = aT_m;
prdData.Lb = Lw_b;
prdData.Lp = Lw_p;
prdData.Li = Lw_i;
prdData.Lim = Lw_im;
prdData.Wwi = Ww_i;
prdData.Ri = RT_i;

%% uni-variate data

  % time-length
  % female
  [tvel, t_p, t_b, l_p, l_b] = get_tp(pars_tp, f_tL, [], tL_f(:,1)*kT_M);
  ELw_f = L_m * tvel(:,4)/ del_M;   % cm, length 
  % male
  tvel = get_tpm(pars_tpm, f_tL, [t_b, f_tL*z/z_m, l_b*z/z_m], tL_m(:,1)*kT_M);
  ELw_m = L_mm * tvel(:,4)/ del_M;   % cm, length 
  % female
  [tvel, t_p, t_b, l_p, l_b] = get_tp(pars_tp, f_tL1, [], tL1_f(:,1)*k_M*TC_tL1);
  ELw_1f = L_m * tvel(:,4)/ del_M;   % cm, length 
  % male
  tvel = get_tpm(pars_tpm, f_tL1, [t_b, f_tL1*z/z_m, l_b*z/z_m], tL1_m(:,1)*k_M*TC_tL1);
  ELw_1m = L_mm * tvel(:,4)/ del_M;   % cm, length 

% pack output
prdData.tL_f = ELw_f;
prdData.tL_m = ELw_m;
prdData.tL1_f = ELw_1f;
prdData.tL1_m = ELw_1m;
