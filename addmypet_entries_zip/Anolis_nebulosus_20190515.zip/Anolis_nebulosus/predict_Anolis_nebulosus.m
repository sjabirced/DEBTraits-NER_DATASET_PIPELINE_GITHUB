function [prdData, info] = predict_Anolis_nebulosus(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
  
  % compute temperature correction factors
  TC = tempcorr(temp.am, T_ref, T_A);
  TC_LdL = tempcorr(temp.LdL_f, T_ref, T_A);
  TC_tp = tempcorr(temp.tp, T_ref, T_A);
  
% zero-variate data

  % life cycle
  pars_tp = [g k l_T v_Hb v_Hp];
  [t_p, t_b, l_p, l_b, info] = get_tp(pars_tp, f);
  
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Lw_b = L_b/ del_M;                % cm, SVL at birth

  % puberty 
  L_p = L_m * l_p;                  % cm, struc length at puberty
  Lw_p = L_p/ del_M;                % cm, SVL at puberty
  tT_p = (t_p - t_b)/ k_M/ TC_tp;      % d, time since birth at puberty

  % ultimate
  l_i = f - l_T;                    % -, scaled ultimate length
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate SVL
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight at f

  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
  RT_i = TC * reprod_rate(L_i, f, pars_R);                % #/d, ultimate reproduction rate at T

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC;                  % d, mean life span at T
  
  % males
  p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
  E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
  g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
  L_mm = v/ k_M/ g_m;                  % cm, max struct length
  pars_tpm = [g_m k l_T v_Hb v_Hp];
  [t_pm, t_bm, l_pm, l_bm] = get_tp(pars_tpm, f);
  L_im = f * L_mm; Lw_im = L_im/ del_M;    % cm, ultimate SVL
  L_pm = l_pm * L_mm; Lw_pm = L_pm/ del_M; % cm,  SVL at puberty
  tT_pm = (t_pm - t_bm)/ k_M/ TC_tp;       % d, time since birth at puberty

  % pack to output
  prdData.tp = tT_p;
  prdData.tpm = tT_pm;
  prdData.am = aT_m;
  prdData.Lb = Lw_b;
  prdData.Lp = Lw_p;
  prdData.Lpm = Lw_pm;
  prdData.Li = Lw_i;
  prdData.Lim = Lw_im;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;
  
  % univar data
  
  % length-change in length
  pars_lb = [g k v_Hb]; pars_lbm = [g_m k v_Hb];
  %
  Lw_i = f_tL * L_m/ del_M;
  rT_B = TC_LdL * k_M/ 3/ (1 + f_tL/ g); % 1/d, von Bert growth rate
  EdLw_f = 1e4 * rT_B * (Lw_i - LdL_f(:,1)); % mum/d, SVL 
  %
  Lw_im = f_tL * L_mm/ del_M;
  rT_Bm = TC_LdL * k_M/ 3/ (1 + f_tL/ g_m); % 1/d, von Bert growth rate
  EdLw_m = 1e4 * rT_B * (Lw_im - LdL_m(:,1)); % mum/d, SVL 

  % pack to output
  prdData.LdL_f = EdLw_f;
  prdData.LdL_m = EdLw_m;
