function [prdData, info] = predict_Zhangixalus_omeimontis(par, data, auxData)
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);

  if E_Hj  < E_Hb || E_Hj > E_Hp
    info = 0; prdData = []; return
  end

  % compute temperature correction factors
  TC = tempcorr(temp.am, T_ref, T_A);
  TC_H = tempcorr(temp.tL_Hfm, T_ref, T_A);
  TC_M = tempcorr(temp.tL_Mfm, T_ref, T_A);
  TC_L = tempcorr(temp.tL_Lfm, T_ref, T_A);
  
  % zero-variate data

  % life cycle
  pars_tj = [g; k; l_T; v_Hb; v_Hj];               % compose parameter vector
  [t_j, t_b, l_j, l_b, info] = get_tp(pars_tj, f);       % -, scaled times & lengths at f
  if ~info; prdData = []; return; end
  pars_tp = [g; k; l_T; v_Hb; v_Hp];               % compose parameter vector
  [t_p, t_b, l_p, l_b, info] = get_tp(pars_tp, f); % -, scaled times & lengths at f
  if ~info; prdData = []; return; end
  
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Ww_b = L_b^3 * (1 + f * w);       % g, wet weight at birth at f
  aT_b = t_b/ k_M/ TC;              % d, age at birth at f and T

  % metam
  L_j = L_m * l_j;                  % cm, structural length at metam at f
  Lw_j = L_j/ del_M;                % cm, SVL at metam
  Ww_j = L_j^3 * (1 + f * w);       % g, wet weight at metam
  tT_j = (t_j - t_b)/ k_M;           % d, time since birth at metam at T_ref
  
  % puberty 
  tT_p = (t_p - t_j)/ k_M/ TC;      % d, time since metam at puberty at f and T
  L_p = L_m * l_p;                  % cm, structural length at puberty
  Lw_p = L_p/ del_M;                % cm, SVL at puberty

  % ultimate
  l_i = f - l_T;                    % -, scaled ultimate length
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate physical length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 
  
  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
  RT_i = TC * reprod_rate(L_i, f, pars_R);                % #/d, ultimate reproduction rate at T

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC;                  % d, mean life span at T
    
  % males
  p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
  E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
  g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
  m_Em_m = y_E_V * E_m_m/ E_G;         % mol/mol, reserve capacity 
  w_m = m_Em_m * w_E/ w_V;             % -, contribution of reserve to weight
  L_mm = v/ k_M/ g_m;                  % cm, max struct length
  L_im = f * L_mm; Lw_im = L_im/ del_M;% cm, ultimate structural, body length
  Ww_im = L_im^3 * (1 + f * w_m);      % g, ultimate wet weight
  pars_tpm = [g_m k l_T v_Hb v_Hp];    % pars for toad
  [t_pm, t_bm, l_pm, l_bm, info] = get_tp(pars_tpm, f); % -, scaled times & lengths at f
  if ~info; prdData = []; return; end
  tT_pm = (t_pm - t_bm)/ k_M/ TC;      % d, time since metam at puberty
  L_pm = l_pm * L_mm; Lw_pm = L_pm/ del_M; % cm, struc, SVL
  Ww_pm = L_pm^3 * (1 + f * w_m);      % g, wet weight at puberty

  % pack to output
  prdData.ab = aT_b;
  prdData.am = aT_m;
  prdData.Lj = Lw_j;
  prdData.Lp = Lw_p;
  prdData.Li = Lw_i;
  prdData.Lim = Lw_im;
  prdData.Wwb = Ww_b;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;
  
  % univariate data
  % time-length
  L_b = L_m * get_lb([g; k; v_Hb], f_H); L_i = L_m * f_H;
  rT_B = TC_H * k_M/ 3/ (1 + f_H/ g); % 1/d, von Bert growth rate
  L = L_i - (L_i - L_b) * exp(- rT_B * tL_Hfm(:,1)); % cm, struc length
  ELw_Hf = L/ del_M; % cm, SVL
  %
  L_bm = L_mm * get_lb([g_m; k; v_Hb], f_H); L_im = L_mm * f_H;
  rT_Bm = TC_H * k_M/ 3/ (1 + f_H/ g_m); % 1/d, von Bert growth rate
  L = L_im - (L_im - L_bm) * exp(- rT_B * tL_Hfm(:,1)); % cm, struc length
  ELw_Hm = L/ del_M; % cm, SVL
  %
  L_b = L_m * get_lb([g; k; v_Hb], f_M); L_i = L_m * f_M;
  rT_B = TC_M * k_M/ 3/ (1 + f_M/ g); % 1/d, von Bert growth rate
  L = L_i - (L_i - L_b) * exp(- rT_B * tL_Mfm(:,1)); % cm, struc length
  ELw_Mf = L/ del_M; % cm, SVL
  %
  L_bm = L_mm * get_lb([g_m; k; v_Hb], f_M); L_im = L_mm * f_M;
  rT_Bm = TC_M * k_M/ 3/ (1 + f_M/ g_m); % 1/d, von Bert growth rate
  L = L_im - (L_im - L_bm) * exp(- rT_B * tL_Mfm(:,1)); % cm, struc length
  ELw_Mm = L/ del_M; % cm, SVL
  %
  L_b = L_m * get_lb([g; k; v_Hb], f_L); L_i = L_m * f_L;
  rT_B = TC_L * k_M/ 3/ (1 + f_L/ g); % 1/d, von Bert growth rate
  L = L_i - (L_i - L_b) * exp(- rT_B * tL_Lfm(:,1)); % cm, struc length
  ELw_Lf = L/ del_M; % cm, SVL
  %
  L_bm = L_mm * get_lb([g_m; k; v_Hb], f_L); L_im = L_mm * f_L;
  rT_Bm = TC_L * k_M/ 3/ (1 + f_L/ g_m); % 1/d, von Bert growth rate
  L = L_im - (L_im - L_bm) * exp(- rT_B * tL_Lfm(:,1)); % cm, struc length
  ELw_Lm = L/ del_M; % cm, SVL


  % pack to output
  prdData.tL_Hfm = [ELw_Hf ELw_Hm];
  prdData.tL_Mfm = [ELw_Mf ELw_Mm];
  prdData.tL_Lfm = [ELw_Lf ELw_Lm];

