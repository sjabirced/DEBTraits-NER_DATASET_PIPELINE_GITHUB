function [data, auxData, metaData, txtData, weights] = mydata_Pecten_maximus

%% set metaData
metaData.phylum     = 'Mollusca'; 
metaData.class      = 'Bivalvia'; 
metaData.order      = 'Pectinida'; 
metaData.family     = 'Pectinidae';
metaData.species    = 'Pecten_maximus'; 
metaData.species_en = 'Great scallop';

metaData.ecoCode.climate = {'MC'};
metaData.ecoCode.ecozone = {'MANE'};
metaData.ecoCode.habitat = {'0jMp', 'jiMb'};
metaData.ecoCode.embryo  = {'Mp'};
metaData.ecoCode.migrate = {};
metaData.ecoCode.food    = {'biPp'};
metaData.ecoCode.gender  = {'D'};
metaData.ecoCode.reprod  = {'O'};

metaData.T_typical  = C2K(13); % K, body temp
metaData.data_0     = {'ab'; 'aj'; 'ap'; 'am'; 'Lb'; 'Lj'; 'Lp'; 'Li'; 'Wdb'; 'Wdj'; 'Wdp'; 'Wdi'; 'Ri'}; 
metaData.data_1     = {'t-L'}; 

metaData.COMPLETE = 2.5; % using criteria of LikaKear2011

metaData.author   = {'Romain Lavaud'};    
metaData.date_subm = [2011 05 10];              
metaData.email    = {'romain.lavaud@hotmail.fr'};            
metaData.address  = {'Institut Universitaire Europeen de la Mer, Plouzane, France'};   

metaData.author_mod_1   = {'Bas Kooijman'};    
metaData.date_mod_1 = [2012 09 24];              
metaData.email_mod_1    = {'bas.kooijman@vu.nl'};            
metaData.address_mod_1  = {'VU University Amsterdam'};   

metaData.author_mod_2   = {'Starrlight Augustine'};    
metaData.date_mod_2 = [2017 05 24];              
metaData.email_mod_2    = {'sta@akvaplan.niva.no'};            
metaData.address_mod_2  = {'Akvaplan-niva'};   


metaData.curator     = {'Bas Kooijman'};
metaData.email_cur   = {'bas.kooijman@vu.nl'}; 
metaData.date_acc    = [2017 05 24]; 

%% set data
% zero-variate data

data.ab = 2;       units.ab = 'd';    label.ab = 'age at birth';             bibkey.ab = {'ShumPars2006','GrufBeau1972'};   
  temp.ab = C2K(18);  units.temp.ab = 'K'; label.temp.ab = 'temperature';
data.tj = 25;      units.tj = 'd';    label.tj = 'time since birth at metam'; bibkey.tj = {'RicoBern2010','ShumPars2006'};   
  temp.tj = C2K(13);  units.temp.tj = 'K'; label.temp.tj = 'temperature';
data.tp = 365;     units.tp = 'd';    label.tp = 'time since birth at puberty'; bibkey.tp = {'Lava2011','ShumPars2006'};
  temp.tp = C2K(13);  units.temp.tp = 'K'; label.temp.tp = 'temperature';
data.am = 20*365;   units.am = 'd';    label.am = 'life span';                bibkey.am = 'ShumPars2006';   
  temp.am = C2K(13);  units.temp.am = 'K'; label.temp.am = 'temperature'; 
  
data.Lb  = 0.008;  units.Lb  = 'cm';  label.Lb  = 'shell height at birth';   bibkey.Lb  = {'ShumPars2006','SamaCoch1987'};
data.Lj  = 0.024;  units.Lj  = 'cm';  label.Lj  = 'shell height at metam';   bibkey.Lj  = {'BuesCoch1982','ShumPars2006'};
data.Lp  = 4.0;    units.Lp  = 'cm';  label.Lp  = 'shell height at puberty'; bibkey.Lp  = {'Lava2011','ShumPars2006'};
data.Li  = 12.0;   units.Li  = 'cm';  label.Li  = 'ultimate shell height';   bibkey.Li  = 'Jean2011';

data.Wdb = 1.04e-7;  units.Wdb = 'g'; label.Wdb = 'dry weight at birth';     bibkey.Wdb = 'Lava2011';
  comment.Wdb = 'computed from length';
data.Wdj = 3e-6;   units.Wdj = 'g'; label.Wdj = 'dry weight at metam';     bibkey.Wdj = {'Ande2011','SamaCoch1987'};
data.Wdp = 1;     units.Wdp = 'g'; label.Wdp = 'dry weight at puberty';   bibkey.Wdp = 'Lava2011';
  comment.Wdp = 'obtained from Lp via LW-regression';
data.Wdi = 20;    units.Wdi = 'g'; label.Wdi = 'ultimate dry weight';     bibkey.Wdi = 'Lava2011';
  comment.Wdi = 'obtained from Li via LW-regression';

data.Ri  = 57534; units.Ri  = '#/d'; label.Ri  = 'maximum reprod rate';     bibkey.Ri  = {'PaulFifa1989','PaulBekh1997'};   
  temp.Ri = C2K(13); units.temp.Ri = 'K'; label.temp.Ri = 'temperature';

  
% uni-variate data

% celtic sea, Romain Lavauds thesis, unpublished work
data.tL1 = [ ... time (julian day), length (cm)
1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31	32	33	34	35	36	37	38	39	40	41	42	43	44	45	46	47	48	49	50	51	52	53	54	55	56	57	58	59	60	61	62	63	64	65	66	67	68	69	70	71	72	73	74	75	76	77	78	79	80	81	82	83	84	85	86	87	88	89	90	91	92	93	94	95	96	97	98	99	100	101	102	103	104	105	106	107	108	109	110	111	112	113	114	115	116	117	118	119	120	121	122	123	124	125	126	127	128	129	130	131	132	133	134	135	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192;
2.003	2.007	2.011	2.016	2.020	2.026	2.033	2.037	2.043	2.049	2.056	2.061	2.067	2.075	2.082	2.091	2.100	2.113	2.125	2.137	2.150	2.160	2.167	2.176	2.187	2.200	2.212	2.224	2.231	2.239	2.245	2.254	2.265	2.273	2.279	2.286	2.292	2.298	2.303	2.309	2.318	2.325	2.333	2.343	2.351	2.363	2.375	2.387	2.398	2.411	2.423	2.436	2.450	2.463	2.475	2.487	2.499	2.512	2.527	2.542	2.560	2.576	2.594	2.610	2.627	2.644	2.664	2.681	2.699	2.714	2.728	2.747	2.764	2.780	2.798	2.814	2.832	2.853	2.872	2.889	2.910	2.930	2.947	2.968	2.988	3.007	3.024	3.041	3.061	3.078	3.097	3.119	3.143	3.162	3.179	3.194	3.215	3.235	3.256	3.276	3.297	3.321	3.342	3.358	3.374	3.394	3.417	3.439	3.458	3.477	3.496	3.518	3.541	3.563	3.584	3.606	3.629	3.650	3.668	3.689	3.708	3.725	3.743	3.760	3.774	3.786	3.802	3.814	3.830	3.842	3.855	3.867	3.878	3.889	3.901	3.910	3.922	3.933	3.943	3.956	3.967	3.980	3.992	4.003	4.014	4.027	4.042	4.058	4.072	4.087	4.098	4.106	4.114	4.123	4.134	4.143	4.158	4.169	4.180	4.190	4.202	4.214	4.227	4.235	4.243	4.249	4.260	4.269	4.277	4.287	4.297	4.304	4.311	4.320	4.329	4.341	4.351	4.362	4.372	4.379	4.385	4.392	4.405	4.411	4.418	4.425	4.433	4.443	4.456	4.466	4.474	4.479
]';
data.tL1(:,1) = data.tL1(:,1); %  julian d to day since birth
units.tL1   = {'d', 'cm'};  label.tL1 = {'time in julian day', 'shell height'};  
temp.tL1    = C2K(12);  units.temp.tL1 = 'K'; label.temp.tL1 = 'temperature';
Lw0.tL1     = 2.0; units.Lw0.tL1 = 'cm'; label.Lw0.tL1 = 'initial shell height';
bibkey.tL1 = 'Lava2014';
comment.tL1 = 'Celtic Sea 162 m - 1 year old, data from chap 6, temp is constant 12 deg C';

% Bay of Brest, Romain lauvauds thesis
data.tL2= [103	104	105	106	107	108	109	110	111	112	113	114	115	116	117	118	119	120	121	122	123	124	125	126	127	128	129	130	131	132	133	134	135	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	203	204	205	206	207	208	209	210	211	212	213	214	215	216	217	218	219	220	221	222	223	224	225	226	227	228	229	230	231	232	233	234	235	236	237	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254	255	256	257	258	259	260	261	262	263	264	265	266	267	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	297	298	299	300	301	302	303	304	305	306	307	308	309	310	311	312	313	314	315	316	317	318	319	320	321	322	323	324	325	326	327	328	329	330	331	332	333	334	335	336	337	338	339	340	341	342	343	344	345	346	347	348	349	350	351	352	353	354	355	356	357	358	359	360	361	362	363	364	365	366	367	368	369	370	371	372	373	374	375	376	377	;																
3.607291	3.614155	3.621019	3.629729	3.637359	3.644477	3.652045	3.659001	3.664984	3.671305	3.677356	3.684178	3.691358	3.698385	3.706307	3.714298	3.722285	3.730339	3.740105	3.749278	3.758389	3.769195	3.778855	3.789352	3.800261	3.811397	3.822441	3.834049	3.845831	3.857219	3.869449	3.881794	3.894279	3.907035	3.920014	3.933547	3.946987	3.96101	3.97686	3.992699	4.009179	4.026606	4.044062	4.061309	4.079422	4.096921	4.114505	4.132472	4.149757	4.167662	4.185645	4.202864	4.220328	4.237861	4.254643	4.271397	4.289299	4.305843	4.323343	4.340485	4.358224	4.375413	4.393086	4.409267	4.426178	4.443144	4.459508	4.475094	4.489946	4.502323	4.514823	4.526225	4.536816	4.546764	4.556341	4.565666	4.574469	4.584289	4.593757	4.60448	4.615949	4.628371	4.64282	4.658992	4.675947	4.693839	4.711962	4.729981	4.748585	4.768249	4.788452	4.810196	4.831546	4.852992	4.875532	4.897281	4.919942	4.942086	4.965308	4.987986	5.010585	5.032892	5.054261	5.074548	5.095961	5.117288	5.138786	5.160043	5.180944	5.200722	5.221639	5.243529	5.264942	5.286674	5.307934	5.329692	5.351984	5.37343	5.395005	5.415007	5.435544	5.455825	5.476259	5.496323	5.517239	5.53683	5.556091	5.575423	5.595651	5.615968	5.636522	5.656939	5.677094	5.697319	5.716861	5.737489	5.756501	5.775869	5.795333	5.814655	5.834099	5.853117	5.872253	5.891247	5.910817	5.92824	5.946134	5.962933	5.980002	5.99763	6.01536	6.032892	6.049862	6.066584	6.084084	6.102319	6.119525	6.135028	6.151359	6.168001	6.184146	6.20068	6.216895	6.233638	6.249801	6.266877	6.284006	6.30093	6.318658	6.335684	6.352954	6.370009	6.387273	6.403545	6.419854	6.437174	6.454471	6.471438	6.488035	6.505388	6.522173	6.53929	6.556225	6.572218	6.588483	6.605028	6.621342	6.637917	6.653677	6.669081	6.684106	6.699066	6.713975	6.729927	6.745311	6.76203	6.777183	6.793142	6.809325	6.824351	6.839629	6.854289	6.868897	6.882961	6.897142	6.911495	6.925906	6.939987	6.953404	6.967087	6.981072	6.993846	7.006292	7.018342	7.030227	7.042387	7.053805	7.064569	7.075795	7.087585	7.099035	7.109643	7.120976	7.131914	7.142266	7.152125	7.161952	7.172019	7.181601	7.190911	7.200394	7.209591	7.218632	7.227595	7.236357	7.236357	7.25342	7.261391	7.269061	7.27788	7.286117	7.294031	7.301878	7.308946	7.315947	7.323503	7.331503	7.338223	7.345657	7.353363	7.35994	7.368211	7.376068	7.383311	7.390045	7.396075	7.402188	7.407384	7.413575	7.420031	7.426176	7.43282	7.439027	7.444515	7.449325	7.454559	7.458324	7.462542	7.467508	7.471855	7.477205	7.48145	7.484113	7.491567	7.495531																	
]';
units.tL2  = {'d', 'cm'};  label.tL2 = {'time', 'length (Bay of Brest)'};  
Lw0.tL2 = 3.6; units.Lw0.tL2 = 'cm'; label.Lw0.tL2 = 'initial physical length'; 
bibkey.tL2 = 'Lava2014'; comment.tL2 = 'Bay of Brest - 1 year old';

% Temperature Time Series bay of brest: day (Julian days), Temperature in deg C
temp.tL2 = [ ... 
    1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31	32	33	34	35	36	37	38	39	40	41	42	43	44	45	46	47	48	49	50	51	52	53	54	55	56	57	58	59	60	61	62	63	64	65	66	67	68	69	70	71	72	73	74	75	76	77	78	79	80	81	82	83	84	85	86	87	88	89	90	91	92	93	94	95	96	97	98	99	100	101	102	103	104	105	106	107	108	109	110	111	112	113	114	115	116	117	118	119	120	121	122	123	124	125	126	127	128	129	130	131	132	133	134	135	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	203	204	205	206	207	208	209	210	211	212	213	214	215	216	217	218	219	220	221	222	223	224	225	226	227	228	229	230	231	232	233	234	235	236	237	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254	255	256	257	258	259	260	261	262	263	264	265	266	267	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	297	298	299	300	301	302	303	304	305	306	307	308	309	310	311	312	313	314	315	316	317	318	319	320	321	322	323	324	325	326	327	328	329	330	331	332	333	334	335	336	337	338	339	340	341	342	343	344	345	346	347	348	349	350	351	352	353	354	355	356	357	358	359	360	361	362	363	364	365	366	367	368	369	370	371	372	373	374	375	376	377;
10.64	10.58	10.52	10.46	10.4	10.34	10.28	10.22	10.16	10.1	10.04	9.98	9.92	9.86	9.8	9.74	9.68	9.62	9.56	9.5	9.44	9.38	9.32	9.25	9.19	9.13	9.07	9.01	8.95	8.89	8.83	8.77	8.71	8.65	8.59	8.53	8.47	8.52	8.56	8.61	8.66	8.71	8.75	8.8	8.85	8.89	8.94	8.99	9.04	9.08	9.13	9.16	9.18	9.21	9.24	9.27	9.29	9.32	9.36	9.4	9.44	9.48	9.52	9.56	9.6	9.64	9.68	9.73	9.77	9.81	9.85	9.89	9.93	9.97	10.01	10.05	10.09	10.04	10.11	10.17	10.24	10.3	10.37	10.44	10.5	10.57	10.64	10.7	10.77	10.83	10.9	10.94	10.97	11.01	11.05	11.08	11.12	11.19	11.14	11.1	11	10.89	10.79	10.69	10.64	10.59	10.54	10.59	10.63	10.68	10.72	10.77	10.9	11.03	11.16	11.29	11.42	11.54	11.65	11.65	11.65	11.65	11.65	11.65	11.74	11.82	11.91	12.1	12.29	12.49	12.68	12.93	13.1	13.28	13.45	13.62	13.8	13.97	14.15	14.32	14.4	14.48	14.56	14.59	14.63	14.66	14.61	14.55	14.46	14.52	14.58	14.64	14.7	14.84	14.98	15.11	15.18	15.25	15.31	15.38	15.45	15.52	15.38	15.39	15.4	15.4	15.41	15.42	15.43	15.56	15.69	15.82	15.96	16.09	16.22	16.35	16.32	16.29	16.25	16.22	16.19	16.16	16.16	16.16	16.16	16.15	16.15	16.15	16.15	16.15	16.15	16.14	16.14	16.14	16.14	16.14	16.14	16.13	16.13	16.13	16.13	16.14	16.16	16.17	16.19	16.2	16.22	16.23	16.25	16.26	16.25	16.24	16.23	16.21	16.2	16.19	16.18	16.32	16.46	16.6	16.74	16.88	17.02	16.93	16.83	16.74	16.64	16.54	16.43	16.33	16.34	16.35	16.36	16.38	16.39	16.4	16.41	16.42	16.4	16.39	16.37	16.36	16.34	16.33	16.31	16.3	16.28	16.27	16.25	16.24	16.22	16.21	16.19	16.18	16.16	16.15	16.13	16.12	16.1	15.89	15.89	15.9	15.9	15.91	15.9	15.89	15.88	15.86	15.85	15.84	15.83	15.69	15.55	15.41	15.27	15.13	14.99	14.85	14.71	14.56	14.42	14.28	14.14	14	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.86	13.78	13.7	13.62	13.54	13.45	13.37	13.29	13.21	13.13	13.04	12.96	12.88	12.76	12.65	12.53	12.42	12.3	12.19	12.07	11.96	11.84	11.72	11.61	11.49	11.38	11.26	11.15	11.03	10.91	10.92	10.93	10.93	10.94	10.94	10.95	10.96	10.96	10.97	10.97	10.98	10.98	10.99	11	10.95	10.91	10.86	10.82	10.77	10.73	10.68	10.64	10.59	10.55	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.51	10.46	10.42	10.37	10.33	10.28
]';
temp.tL2    = [temp.tL2(:,1) C2K(temp.tL2(:,2))];  
units.temp.tL2 = 'K'; label.temp.tL2 = 'temperature';

% Traena Date (Julian day)Length (cm)	
data.tL3 = [ ...
    151	152	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	203	204	205	206	207	208	209	210	211	212	213	214	215	216	217	218	219	220	221	222	223	224	225	226	227	228	229	230	231	232	233	234	235	236	237	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254	255	256	257	258	259	260	261	262	263	264	265	266	267	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	297	298	299	300	301	302	303	304	305	306	307	308	309	310	311	312	313	314	315	316	317	318	319	320	321	322	323	324	325	326	327	328	;																																																																																																														
	1.815	1.828	1.841	1.859	1.869	1.880	1.894	1.910	1.928	1.944	1.961	1.981	2.000	2.016	2.030	2.041	2.054	2.067	2.084	2.102	2.118	2.136	2.153	2.169	2.183	2.197	2.214	2.228	2.242	2.260	2.282	2.302	2.320	2.340	2.358	2.375	2.395	2.415	2.434	2.450	2.465	2.484	2.504	2.524	2.544	2.565	2.585	2.606	2.627	2.648	2.669	2.692	2.715	2.738	2.761	2.784	2.807	2.827	2.849	2.874	2.897	2.919	2.941	2.964	2.987	3.010	3.034	3.055	3.079	3.101	3.125	3.149	3.171	3.195	3.218	3.242	3.265	3.289	3.312	3.336	3.359	3.381	3.405	3.429	3.452	3.475	3.497	3.520	3.544	3.565	3.586	3.608	3.630	3.650	3.671	3.693	3.715	3.736	3.759	3.783	3.806	3.827	3.848	3.870	3.891	3.912	3.932	3.953	3.976	3.996	4.017	4.037	4.059	4.081	4.103	4.123	4.143	4.164	4.186	4.208	4.230	4.251	4.272	4.293	4.317	4.338	4.358	4.380	4.402	4.423	4.445	4.466	4.489	4.513	4.535	4.557	4.579	4.601	4.623	4.646	4.669	4.690	4.711	4.731	4.751	4.771	4.791	4.811	4.831	4.851	4.871	4.891	4.908	4.926	4.945	4.961	4.978	4.995	5.012	5.029	5.045	5.060	5.073	5.085	5.094	5.103	5.112	5.121	5.129	5.136	5.143	5.149	5.156	5.164	5.172	5.179	5.186	5.190																																																																																																															
]';																																																																																																																																																																																																																																																																																																	
units.tL3  = {'d', 'cm'};  label.tL3 = {'time - julian day', 'length (Traena)'};  
Lw0.tL3 = 1.8; units.Lw0.tL3 = 'cm'; label.Lw0.tL3 = 'initial physical length'; 
bibkey.tL3 = 'Lava2014'; comment.tL3 = 'Traena Norway - 3 year old';
																																																																																																																																																																																																																																																																																																	
% Temperature Time Series Traena Norway
	temp.tL3 = [ ...  Temperature deg C, 	Julian Day																																																																																																																																																																																																																																																																																																
	6.6	6.6	6.4	6.4	6.4	6.2	6.2	5.8	5	5	5.8	5.8	5.6	5.8	5	4.8	4.8	4.8	4.8	6	6.2	6	5.4	5.2	4.2	4.2	4.6	4.8	5	5.2	4.8	5	5	4.8	4.6	4.8	4.6	4.4	4.2	4.2	4.4	4.2	4	3.9	3.6	4	4.4	4.6	4.6	4.4	4.4	4.2	4.2	4.4	4.5	4.6	4.6	4.7	4.8	4.2	4.6	5	5	5	5	5	4.8	4.8	4.8	4.8	5	5	5.2	5.2	5.2	5.4	5.6	5.6	5.8	5.8	5.8	5.8	5.6	5.6	5.8	5.8	6	6	6	6.2	6.2	6.4	6.4	6.4	6.4	6.6	6.6	6.6	6.6	7.2	7.2	7.4	7.6	7.8	7.8	8	8	8	8.2	8.2	8.2	8.2	9	9	9	9.6	9.6	9.4	10	10	10.4	10.6	10.4	9.8	9.8	9.4	9.4	10	10	10.6	12	11.6	11.8	11.6	11.6	11.6	11.6	11.6	11.6	11.6	12.4	12.4	12.4	12.4	12.6	12.6	12.8	13.2	13.4	13.4	13.4	13	12.8	12.8	13	13	12.4	12.4	12.8	12.6	12.4	12.4	12	12.2	12.2	12	12	12.2	12	12	12	12.2	12.4	12.2	12.2	12	11.8	11.8	11.8	12	12	12	11.8	11.8	11.8	11.6	11.8	11.4	11.6	11.8	12	11.8	11.8	11.8	11.8	11.7	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.8	11.6	11.4	11.2	11	11	11	11	11	10.8	10.6	10.8	11.8	11.6	11.2	11.4	11.2	11.2	11.2	11.2	11	11	11	11	11	11.2	11	10.8	10.8	11	11	10.6	10.6	10.2	10.2	10	10.2	10.2	9.8	9.8	9.8	9.8	9	9.3	8.8	8.8	8.6	8.6	8.5	8.8	9.2	9.2	9	8.8	8	8	8	7.8	6.8	6.8	6.6	6.8	6	6.4	6	6.4	6.4	6	6	5.2	5.5	5.5	5.5	5.5	6	5.8	6.6	5.8	5.9	6.2;
1	2	4	5	6	7	8	11	14	15	19	20	21	22	25	26	27	28	29	32	33	35	36	37	39	40	41	43	49	51	53	54	55	56	60	61	62	63	64	65	67	68	69	70	71	74	76	77	78	79	81	82	83	86	88	89	90	91	92	93	95	96	97	98	99	100	102	103	104	105	106	107	109	110	111	112	113	114	116	117	118	119	120	121	123	124	125	126	127	128	130	131	132	133	134	135	138	139	140	141	142	145	146	147	148	149	151	152	154	155	156	157	159	160	161	162	163	164	166	167	168	169	170	171	173	174	175	176	177	178	180	181	182	183	184	186	187	188	189	190	191	193	194	195	196	197	200	201	202	203	205	206	207	208	210	211	213	214	215	217	218	219	220	221	222	223	224	225	226	227	228	229	230	231	232	233	235	236	237	238	239	240	241	243	244	245	246	247	248	249	250	251	252	253	254	255	256	257	258	259	260	261	262	263	264	265	266	267	268	269	270	271	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288	289	290	291	292	293	294	295	296	297	298	299	302	305	308	309	310	311	312	313	314	315	316	318	319	321	322	323	324	326	327	328	329	330	332	335	336	337	338	340	341	343	344	346	347	348	349	350	351	352	354	355	356	357	358	360	361	362	363	364	365
]';
temp.tL3    = [temp.tL3(:,2) C2K(temp.tL3(:,1))];   % julian day first column and then temp converted to kelvin in the second column
units.temp.tL3 = 'K'; label.temp.tL3 = 'temperature';

% % t-L data from Bay of Brest by Fred Jean
% data.tL = [ ... % time since birth (a), shell height (cm)
% 1	1.8
% 1	1.8
% 1	1.9
% 1	2
% 1	2
% 1	2
% 1	2
% 1	2.1
% 1	2.1
% 1	2.1
% 1	2.2
% 1	2.2
% 1	2.3
% 1	2.3
% 1	2.4
% 1	2.4
% 1	2.4
% 1	2.4
% 1	2.4
% 1	2.4
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.5
% 1	2.55
% 1	2.6
% 1	2.6
% 1	2.6
% 1	2.6
% 1	2.6
% 1	2.6
% 1	2.7
% 1	2.7
% 1	2.7
% 1	2.7
% 1	2.8
% 1	2.8
% 1	2.8
% 1	2.8
% 1	2.8
% 1	2.8
% 1	2.8
% 1	2.85
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	2.9
% 1	3
% 1	3
% 1	3
% 1	3
% 1	3
% 1	3
% 1	3.1
% 1	3.1
% 1	3.1
% 1	3.3
% 1	3.4
% 1	4
% 2	3.25
% 2	3.4
% 2	3.6
% 2	3.7
% 2	3.8
% 2	4
% 2	4
% 2	4
% 2	4
% 2	4
% 2	4.2
% 2	4.4
% 2	4.4
% 2	4.5
% 2	4.5
% 2	4.6
% 2	4.9
% 2	4.9
% 2	5
% 2	5.3
% 2	5.3
% 2	5.6
% 2	5.7
% 2	5.7
% 2	5.8
% 2	5.8
% 2	5.8
% 2	5.9
% 2	6
% 2	6.1
% 2	6.1
% 2	6.1
% 2	6.1
% 2	6.2
% 2	6.2
% 2	6.2
% 2	6.2
% 2	6.2
% 2	6.2
% 2	6.3
% 2	6.3
% 2	6.3
% 2	6.3
% 2	6.3
% 2	6.3
% 2	6.3
% 2	6.4
% 2	6.4
% 2	6.5
% 2	6.5
% 2	6.5
% 2	6.5
% 2	6.5
% 2	6.5
% 2	6.5
% 2	6.6
% 2	6.6
% 2	6.7
% 2	6.8
% 2	6.9
% 2	6.9
% 2	6.9
% 2	7
% 2	7.1
% 2	7.1
% 2	7.4
% 2	7.6
% 3	6
% 3	6
% 3	6
% 3	6.2
% 3	6.5
% 3	6.5
% 3	6.5
% 3	6.5
% 3	6.6
% 3	6.65
% 3	6.8
% 3	7
% 3	7
% 3	7
% 3	7.1
% 3	7.1
% 3	7.1
% 3	7.1
% 3	7.2
% 3	7.2
% 3	7.3
% 3	7.3
% 3	7.4
% 3	7.4
% 3	7.4
% 3	7.5
% 3	7.5
% 3	7.5
% 3	7.7
% 3	7.7
% 3	7.7
% 3	7.8
% 3	7.8
% 3	7.9
% 3	8
% 3	8
% 3	8.1
% 3	8.2
% 3	8.2
% 3	8.2
% 3	8.3
% 3	8.3
% 3	8.4
% 3	8.4
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.5
% 3	8.6
% 3	8.6
% 3	8.7
% 3	8.7
% 3	8.7
% 3	8.7
% 3	8.8
% 3	8.9
% 3	9.1
% 3	9.1
% 3	9.1
% 3	9.1
% 3	9.2
% 3	9.2
% 3	9.2
% 4	7.4
% 4	7.4
% 4	7.5
% 4	7.5
% 4	7.7
% 4	7.8
% 4	7.9
% 4	8.4
% 4	8.4
% 4	8.5
% 4	8.5
% 4	8.5
% 4	8.6
% 4	8.6
% 4	8.8
% 4	8.8
% 4	8.8
% 4	8.8
% 4	8.8
% 4	8.8
% 4	8.9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9
% 4	9.1
% 4	9.1
% 4	9.15
% 4	9.2
% 4	9.2
% 4	9.3
% 4	9.3
% 4	9.4
% 4	9.4
% 4	9.4
% 4	9.4
% 4	9.4
% 4	9.4
% 4	9.5
% 4	9.6
% 4	9.8
% 4	9.9
% 4	9.9
% 4	10
% 4	10.1
% 4	10.2
% 4	10.2
% 4	10.5
% 5	9.2
% 5	9.1
% 5	9.1
% 5	9.5
% 5	9.5
% 5	9.5
% 5	9.6
% 5	9.9
% 5	10
% 5	10
% 5	10
% 5	10.3
% 1	0.9
% 1	2.4
% 1	4.9
% 2	4.3
% 2	6.2
% 2	8.3
% 3	6.2
% 3	8.3
% 3	9.6
% 4	8
% 4	9.5
% 4	11.1
% 5	8.9
% 5	10.1
% 5	11.7
% 6	9.2
% 6	10.6
% 6	11.9
% 7	9.8
% 7	10.8
% 7	12] ;
% data.tL(:,1) = data.tL(:,1) * 365; % covert yr to d
% units.tL   = {'d', 'cm'};  label.tL = {'time since birth', 'shell height'};  
% temp.tL    = C2K(16);  units.temp.tL = 'K'; label.temp.tL = 'temperature';
% bibkey.tL = 'Jean2011';
  
%% set weights for all real data
weights = setweights(data, []);
weights.Lb = 0 * weights.Lb; % must be another shape
weights.Lj = 0 * weights.Lj; % must be another shape

weights.tL1 = 20 * weights.tL1; % 
weights.tL2 = 80 * weights.tL2; % 
weights.tL3 = 200 * weights.tL3; % 

% weights.tL = 10 * weights.tL; % value out of range

%% set pseudodata and respective weights
[data, units, label, weights] = addpseudodata(data, units, label, weights);

%% pack auxData and txtData for output
auxData.temp = temp;
auxData.Lw0 = Lw0;
txtData.units = units;
txtData.label = label;
txtData.bibkey = bibkey;
txtData.comment = comment;

%% Links
metaData.links.id_CoL = '767GC'; % Cat of Life
metaData.links.id_ITIS = '79683'; % ITIS
metaData.links.id_EoL = '46467904'; % Ency of Life
metaData.links.id_Wiki = 'Pecten_maximus'; % Wikipedia
metaData.links.id_ADW = 'Pecten_maximus'; % ADW
metaData.links.id_Taxo = '39421'; % Taxonomicon
metaData.links.id_WoRMS = '140712'; % WoRMS
metaData.links.id_molluscabase = '140712'; % molluscabase


%% References
bibkey = 'Wiki'; type = 'Misc'; bib = ...
'howpublished = {\url{http://en.wikipedia.org/wiki/Pecten_maximus}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Kooy2010'; type = 'Book'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Kooijman, S. A. L. M.}, ' ...
'year = {2010}, ' ...
'title  = {Dynamic Energy Budget theory for metabolic organisation}, ' ...
'publisher = {Cambridge Univ. Press, Cambridge}, ' ...
'pages = {Table 4.2 (page 150), 8.1 (page 300)}, ' ...
'howpublished = {\url{../../../bib/Kooy2010.html}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'ShumPars2006'; type = 'Incollection'; bib = [ ... 
'author = {Shumway, S. E. and Parsons, G. J.}, ' ... 
'year = {2006}, ' ...
'title = {Scallops: Biology, Ecology and Aquaculture.}, ' ...
'publisher = {Elsevier}, ' ...
'booktitle = {Developments in Aquaculture and Fisheries Science}, ' ...
'volume = {35}, '...
'address = {Amsterdam}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'SamaCoch1987'; type = 'Article'; bib = [ ... 
'author = {Samain J. F. and J. C. Cochard and L. Chevaulot and J. Y. Daniel and C. Jeanthon and J. R. Le Coz and Y. Marty and J. Moal and D. Prieur and M. Sala\"{u}n}, ' ... 
'year = {1987}, ' ...
'title = {Effect of water quality on the growth of \emph{Pecten maximus} larvae in nursery: {F}irst observations}, ' ...
'journal = {Haliotis}, ' ...
'volume = {16}, ' ...
'pages = {363--381}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'RicoBern2010'; type = 'Article'; bib = [ ... 
'author = {Rico-Villa, B. and Bernard, I. and Robert, R. and Pouvreau, S.}, ' ... 
'year = {2010}, ' ...
'title = {A {D}ynamic {E}nergy {B}udget ({D}{E}{B}) growth model for pacific oyster larvae, \emph{Crassostrea gigas}}, ' ...
'journal = {Aquaculture}, ' ...
'volume = {305}, ' ...
'pages = {84--94}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'PaulBekh1997'; type = 'Article'; bib = [ ... 
'author = {Paulet, Y.-M. and Bekhadra, F. and Devauchelle, N. and Donval, A. and Dorange, G.}, ' ... 
'year = {1997}, ' ...
'title = {Seasonal cycles, reproduction and oocyte quality in \emph{Pecten maximus} from the {B}ay of {B}rest}, ' ...
'journal = {Annales de l Institut oceanographique}, ' ...
'volume = {73}, ' ...
'number = {1}, '...
'pages = {101--112}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'PaulFifa1989'; type = 'Article'; bib = [ ... 
'author = {Paulet Y.-M. and Fifas, S.}, ' ... 
'year = {1989}, ' ...
'title = {Etude de la fecondite potentielle de la coquille {S}aint-{J}acques \emph{Pecten maximus}, en {B}aie de {S}aint-{B}rieue.}, ' ...
'journal = {Haliotis}, ' ...
'volume = {19}, ' ...
'pages = {275--285}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'GrufBeau1972'; type = 'Article'; bib = [ ... 
'author = {Gruffydd, L. D. and Beaumont, A. R.}, ' ... 
'year = {1972}, ' ...
'title = {A method for rearing Pecten maximus larvae in the laboratory}, ' ...
'journal = {Marine Biology}, ' ...
'volume = {15}, ' ...
'number = {4}, '...
'pages = {350--355}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'BuesCoch1982'; type = 'Article'; bib = [ ... 
'author = {Buestel, D. and Cochard, J.-C. and Dao, J.-C. and Gerard, A.}, ' ... 
'year = {1982}, ' ...
'title = {Artificial production of great scallop \emph{Pecten maximus} ({L}.) spat. {F}irst results in the {B}ay of {B}rest}, ' ...
'journal = {Vie Marine-Annales de la Fondation oceanographique Ricard}, ' ...
'volume = {4}, ' ...
'pages = {24--28}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Jean2011'; type = 'Misc'; bib = [...
'author = {Jean, f.}, ' ...     
'year = {2011}, ' ...
'note = {Own measurements in Bay of Brest}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Lava2011'; type = 'Misc'; bib = [...
'author = {Lavaud, R.}, ' ...     
'year = {2011}, ' ...
'note = {Own measurements in Bay of Brest}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Ande2011'; type = 'Misc'; bib = [...
'author = {Sissel Andersen}, ' ...     
'year = {2011}, ' ...
'note = {Pers. com}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Lava2014'; type = 'PhdThesis'; bib = [...
'author = {Romain Lavuad}, ' ...     
'year = {2014}, ' ...
'title = {Environmental variability and energetic adaptability of the great scallop, \emph{Pecten maximus}, facing climate change}, ' ...
'school = {Vrije Universiteit Amsterdam}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];


