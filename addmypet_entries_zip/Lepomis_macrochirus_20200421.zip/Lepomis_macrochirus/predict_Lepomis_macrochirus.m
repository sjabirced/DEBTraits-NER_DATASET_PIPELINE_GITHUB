function [prdData, info] = predict_Lepomis_macrochirus(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
  
  % compute temperature correction factors
  TC_ab = tempcorr(temp.ab, T_ref, T_A);
  TC_tp = tempcorr(temp.tp, T_ref, T_A);
  TC_am = tempcorr(temp.am, T_ref, T_A);
  TC_Ri = tempcorr(temp.Ri, T_ref, T_A);
  TC_tL = tempcorr(temp.tL, T_ref, T_A);
  TC_tW_f = tempcorr(temp.tW_f, T_ref, T_A);
  
   
  % zero-variate data

  % life cycle
  pars_tj = [g k l_T v_Hb v_Hj v_Hp];
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tj, f);
 
  % birth 
  L_b = L_m * l_b;                  % cm, structural length at birth (swim up) at f 
  Lw_b = L_b/ del_M;                % cm, total length at birth (swim up) at f 
  aT_b = t_b/ k_M/ TC_ab;           % d, age at birth (swim up) at f and T
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Ww_p = L_p^3 *(1 + f * w);        % g, wet weight at puberty 
  tT_p = (t_p - t_b)/ k_M/ TC_tp;   % d, time since birth at puberty at f and T

  % ultimate
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate physical length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 
 
  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hj; U_Hp]; % compose parameter vector at T
  RT_i = TC_Ri * reprod_rate_j(L_i, f, pars_R);   % #/d, ultimate reproduction rate at T
  

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC_am;               % d, mean life span at T
  
  % pack to output
  prdData.ab = aT_b;
  prdData.tp = tT_p;
  prdData.am = aT_m;
  prdData.Lb = Lw_b;
  prdData.Li = Lw_i;
  prdData.Wwp = Ww_p;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;
   
  
  % uni-variate data
  
  % time-length 
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B] = get_tj(pars_tj, f_tL);
  kT_M = k_M * TC_tL; rT_j = rho_j * kT_M; rT_B = rho_B * kT_M; tT_j = (t_j - t_b)/ kT_M;
  L_b = L_m * l_b; L_j = L_m * l_j; L_i = L_m * l_i;
  L_bj = L_b * exp(rT_j * tL(tL(:,1) < tT_j,1)/ 3);
  L_ji = L_i - (L_i - L_j) * exp( - rT_B * (tL(tL(:,1) >= tT_j,1) - tT_j)); % cm, structural length
  ELw = [L_bj; L_ji]/ del_M; % cm, total length  
  % time-weight
  L_bj = L_b * exp(rT_j * tW(tW(:,1) < tT_j,1)/ 3);
  L_ji = L_i - (L_i - L_j) * exp( - rT_B * (tW(tW(:,1) >= tT_j,1) - tT_j)); % cm, structural length
  EWw = [L_bj; L_ji].^3 * (1 + f * ome); % g, wet weight (same parameters as Elw)
  
  % time-weight female post metam
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B] = get_tj(pars_tj, f_tW_f);
  kT_M = k_M * TC_tW_f; rT_B = rho_B * kT_M; tT_j = (t_j - t_b)/ kT_M;
  L_j = L_m * l_j; L_i = L_m * l_i;
  EWw_f = (L_i - (L_i - L_j * del_M) * exp( - rT_B * (tW_f(:,1) - tT_j))).^3 * (1 + f_tW_f * w); % g, wet weight
  
  % pack to output
  prdData.tL = ELw;  % time (d) vs length (cm)
  prdData.tW = EWw;  % time (d) vs wet weight (g)
  prdData.tW_f = EWw_f;  % time (d) vs wet weight (g) in females
 

