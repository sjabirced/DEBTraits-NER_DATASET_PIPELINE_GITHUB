function [prdData, info] = predict_Gallus_gallus_IR(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);

  if E_Hb >= E_Hx || E_Hx >= E_Hp
      prdData = []; info = 0; return
  end
  
  % compute temperature correction factors
  TC_ab = tempcorr(temp.ab, T_ref, T_A);
  TC = tempcorr(temp.am, T_ref, T_A); kT_M = TC * k_M;
  
  % zero-variate data

  % life cycle
  pars_tR = [g; k; l_T; v_Hb; v_Hx; v_Hp; t_N * kT_M];  % compose parameter vector
  [t_R, t_p, t_x, t_b, l_R, l_p, l_x, l_b, info] = get_tR(pars_tR, f); % -, scaled times & lengths at f
  
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Ww_b = L_b^3 * (1 + f * w);       % g, wet weight at birth at f 
  aT_b = t_0 + t_b/ k_M/ TC_ab;     % d, age at birth at f and T

  % fledging
  tT_x = (t_x - t_b)/ kT_M;         % d, time since birth at fledging at f and T

  % puberty
  tT_p = (t_p - t_b)/ kT_M;         % d, time since birth at puberty at f and T
  
  % ultimate
  l_i = f - l_T;                    % -, scaled ultimate length
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 
 
  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
  RT_i = TC * reprod_rate(L_i, f, pars_R);             % #/d, ultimate reproduction rate at T
  tT_R = (t_R - t_b)/ kT_M;        % d, time since birth at 1st brood at f and T
  L_R = L_m * l_R;                  % cm, structural length at 1st brood at f
  Ww_R = L_R^3 * (1 + f * w);       % g, wet weight 1st brood

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ kT_M;                     % d, mean life span at T

  % males
  p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
  pT_Am_m = p_Am_m * TC;            % J/d.cm^2, {p_Am} spec assimilation flux, temp corrected
  E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
  g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
  m_Em_m = y_E_V * E_m_m/ E_G;         % mol/mol, reserve capacity 
  w_m = m_Em_m * w_E/ w_V;             % -, contribution of reserve to weight
  L_mm = v/ k_M/ g_m;                  % cm, max struct length
  L_im = (f - l_T) * L_mm;             % cm, ultimate structural length
  Ww_im = L_im^3 * (1 + f * w_m);      % g, ultimate wet weight
  pars_tRm = [g_m; k; l_T; v_Hb; v_Hx; v_Hpm; t_N * kT_M];  % compose parameter vector
  [t_Rm, t_pm, t_xm, t_bm, l_Rm, l_pm, l_xm, l_bm, info] = get_tR(pars_tRm, f); % -, scaled times & lengths at f
  Ww_Rm = (l_Rm * L_mm)^3 * (1 + f * w_m); % g, wet weight at 1st brood
  tT_Rm = (t_Rm - t_bm)/ kT_M;         % d, time since birth at 1st brood

  % pack to output
  prdData.ab = aT_b;
  prdData.tx = tT_x;
  prdData.tp = tT_p;
  prdData.tR = tT_R;
  prdData.tRm = tT_Rm;
  prdData.am = aT_m;
  prdData.Wwb = Ww_b;
  prdData.WwR = Ww_R;
  prdData.WwRm = Ww_Rm;
  prdData.Wwi = Ww_i;
  prdData.Wwim = Ww_im;
  prdData.Ri = RT_i;
  
  % uni-variate data
  
  % time-weight at varying f
  
  vT = v * TC; pT_Am = p_Am * TC; pT_M = p_M * TC; kT_J = k_J * TC;
  %females
  tJ_X = feed.tW_f; tJ_X(:,2) = tJ_X(:,2)/ w_X;
  [a eL] = ode45(@dget_eL, tW_f(:,1), [1; L_b], [], vT, g, L_T, L_m, pT_Am, tJ_X, 0, kap_Xf, mu_Xf);
  pT_C = E_m * eL(:,1) .* eL(:,2).^3 .* (E_G * vT ./ eL(:,2) + pT_M) ./ (kap * eL(:,1) * E_m + E_G);
  % contribution of egg production to weight for eggs laid one at a time is half the investment per day
  EW_R = 0.5 * ((1 - kap) * pT_C - kT_J * E_Hp) * w_E/ mu_E; % 0.5 * weight of eggs per day
  EWw_f = EW_R + eL(:,2).^3 .* (1 + eL(:,1) * w); % g, wet weight
  % tR_f and tW0_f have the same time points
  n = size(tR,1); EW_R = zeros(n,1); EWw_0 = EW_R; 
  pars_UE0 = [V_Hb; g; k_J; k_M; v];
  t = [-1e-10; tR(:,1)];
  [a eL] = ode45(@dget_eL, t, [1; L_b], [], vT, g, L_T, L_m, pT_Am, tJ_X, 0, kap_Xf, mu_Xf);
  eL(1,:) = [];
  for i = 1:n  
    EWw_0(i) = w_E * J_E_Am * initial_scaled_reserve(eL(i,1), pars_UE0)/ d_E; % g, egg wet weight
    EW_R(i) = EWw_0(i) * TC * reprod_rate(eL(i,2), eL(i,1), pars_R); % #/d, ultimate reproduction rate at T
  end
  %
  tJ_X = feed.tW2_f; tJ_X(:,2) = tJ_X(:,2)/ w_X; % d,mol/d: time, food intake
  [a eL] = ode45(@dget_eL, tW2_f(:,1), [1; L_b], [], vT, g, L_T, L_m, pT_Am, tJ_X, 1, kap_X, mu_X);
  pT_C = E_m * eL(:,1) .* eL(:,2).^3 .* (E_G * vT ./ eL(:,2) + pT_M) ./ (kap * eL(:,1) * E_m + E_G);
  % contribution of egg production to weight for eggs laid one at a time is half the investment per day
  W_R = 0.5 * ((1 - kap) * pT_C - kT_J * E_Hp) * w_E/ mu_E; % 0.5 * weight of eggs per day
  EWw_f2 = W_R + eL(:,2).^3 .* (1 + eL(:,1) * w); % g, wet weight

  % males
  tJ_X = feed.tW_m; tJ_X(:,2) = tJ_X(:,2)/ w_X;
  [a eL] = ode45(@dget_eL, tW_m(:,1), [1; L_b], [], vT, g_m, L_T, L_mm, pT_Am_m, tJ_X, 0, kap_Xf, mu_Xf);
  EWw_m = eL(:,2).^3 .* (1 + eL(:,1) * w); % g, wet weight
  %
  tJ_X = feed.tW2_m; tJ_X(:,2) = tJ_X(:,2)/ w_X; % d,mol/d: time, food intake
  [a eL] = ode45(@dget_eL, tW2_m(:,1), [1; L_b], [], vT, g_m, L_T, L_mm, pT_Am_m, tJ_X, 1, kap_X, mu_X);
  EWw_m2 = eL(:,2).^3 .* (1 + eL(:,1) * w); % g, wet weight
 
  % pack to output
  prdData.tW_f = EWw_f;
  prdData.tW_m = EWw_m;
  prdData.tW2_f = EWw_f2;
  prdData.tW2_m = EWw_m2;
  prdData.tW0 = EWw_0;
  prdData.tR = EW_R;
  
end

%% subfunctions

function deL = dget_eL(t, eL, v, g, L_T, L_m, p_Am, tJ_X, i, kap_X, mu_X)

  e = eL(1); % -, scaled reserve density
  L = eL(2); % structural length
  
  if i == 0 && t < 7
    f = 1;
  else
    p_A = kap_X * mu_X * spline1(t, tJ_X);   % J/d, intake rate
    f = p_A/ (p_Am * L^2);  % -, scaled functional response
  end
  de = (f - e) * v/ L;
  r = v * (e/ L - (1 + L_T/ L)/ L_m)/ (e + g);
  dL = L * r/ 3;
  
  % de/dt and dL/dt
  deL = [de; dL];
end