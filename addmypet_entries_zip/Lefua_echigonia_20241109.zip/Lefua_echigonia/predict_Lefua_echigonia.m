function [prdData, info] = predict_Lefua_echigonia(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
  
%% compute temperature correction factors
  TC = tempcorr(temp.am, T_ref, T_A); kT_M = k_M * TC; 

  % life cycle
  pars_tj = [g k l_T v_Hb v_Hj v_Hp];
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tj, f);

  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth of foetus  at f = 1
  Lw_b = L_b/ del_M;                % cm, total length at birth
  Ww_b = L_b^3 * (1 + f * w);       % g, wet weight at birth
  a_b = t_b/ k_M;                   % d, age at birth at T_ref
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Lw_p = L_p/ del_M;                % cm, standard length at puberty at f
  Ww_p = L_p^3 * (1 + f * w);       % g, wet weight at puberty
  tT_p = (t_p - t_b)/ kT_M;         % d, time since birth at puberty at f and T
  s_M = l_p/ l_b;                   % -, acceleration factor

  % ultimate
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate standard length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 
  
  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hj; U_Hp]; % compose parameter vector
  RT_i = TC * reprod_rate_j(L_i, f, pars_R); % #/d, max reprod rate

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ kT_M;                     % d, mean life span at T

  % males
  p_Am_m = z_m * p_M/ kap;             % J/d.cm^2, {p_Am} spec assimilation flux
  E_m_m = p_Am_m/ v;                   % J/cm^3, reserve capacity [E_m]
  g_m = E_G/ (kap* E_m_m);             % -, energy investment ratio
  m_Em_m = y_E_V * E_m_m/ E_G;         % mol/mol, reserve capacity 
  w_m = m_Em_m * w_E/ w_V;             % -, contribution of reserve to weight
  L_mm = v/ k_M/ g_m;                  % cm, max struct length
  pars_tjm = [g_m k l_T v_Hb v_Hj v_Hp];
  [t_jm, t_pm, t_bm, l_jm, l_pm, l_bm, l_im, rho_jm, rho_Bm] = get_tj(pars_tjm, f);
  tT_pm = (t_pm - t_bm)/ k_M/ TC;      % d, age at puberty
  L_pm = L_mm * l_pm; Lw_pm = L_pm/ del_M; % cm, total length at puberty
  L_im = L_mm * l_im; Lw_im = L_im/ del_M; % cm, ultimate total length
  Ww_pm = L_pm.^3 * (1 + f * w_m);     % g, wet weight at puberty

  % pack to output
  prdData.am = aT_m;
  prdData.Lp = Lw_p;
  prdData.Li = Lw_i;
  prdData.Lim = Lw_im;
  prdData.Wwb = Ww_b;
  prdData.Wwp = Ww_p;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;

  % time-length, assume post-acceleration
  % female
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B] = get_tj(pars_tj, f_tL);  
  r_j=rho_j*k_M; r_B=rho_B*k_M; L_b=L_m*l_b; L_j=L_m*l_j; L_i=L_m*l_i; 
  [t, L] = ode45(@dget_L, [0;tL_f(:,1)], L_b, [], L_j, L_i, r_j, r_B, T_ref, T_A, t_0); % cm, struc length
  L(1)=[]; ELw_f = L/ del_M; % cm, standard length
  %
  [t_jm, t_pm, t_bm, l_jm, l_pm, l_bm, l_im, rho_jm, rho_Bm] = get_tj(pars_tjm, f_tL);  
  r_jm=rho_jm*k_M; r_Bm=rho_Bm*k_M; L_bm=L_mm*l_bm; L_jm=L_mm*l_jm; L_im=L_mm*l_im; 
  [t, L] = ode45(@dget_L, [0;tL_m(:,1)], L_bm, [], L_jm, L_im, r_jm, r_Bm, T_ref, T_A, t_0); % cm, struc length
  L(1)=[]; ELw_m = L/ del_M; % cm, standard length
  
  % pack to output
  prdData.tL_f = ELw_f;
  prdData.tL_m = ELw_m;

end

function dL = dget_L(t, L, L_j, L_i, r_j, r_B, T_ref, T_A, t_0)
  TC = tempcorr(C2K(12.5 + 7.5 * sin(2*pi*(t-t_0)/365)), T_ref, T_A);
  if L<L_j
    dL = TC * r_j * L/ 3;
  else
    dL = TC * r_B * (L_i - L); 
  end
end  

