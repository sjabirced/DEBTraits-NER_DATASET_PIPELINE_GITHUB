function [data, auxData, metaData, txtData, weights] = mydata_Crocodylus_johnsoni

%% set metaData
metaData.phylum     = 'Chordata'; 
metaData.class      = 'Reptilia'; 
metaData.order      = 'Crocodilia'; 
metaData.family     = 'Crocodilidae';
metaData.species    = 'Crocodylus_johnsoni'; 
metaData.species_en = 'Australian freshwater crocodile'; 

metaData.ecoCode.climate = {'BSh'};
metaData.ecoCode.ecozone = {'TA'};
metaData.ecoCode.habitat = {'0bTd', 'biFm', 'biFr'};
metaData.ecoCode.embryo  = {'Tt'};
metaData.ecoCode.migrate = {};
metaData.ecoCode.food    = {'bpCi', 'biCv'};
metaData.ecoCode.gender  = {'Dtfm'};
metaData.ecoCode.reprod  = {'O'};

metaData.T_typical  = C2K(22); % K, body temp
metaData.data_0     = {'ab'; 'ap'; 'am'; 'Lb'; 'Lp'; 'Li'; 'Wwb'; 'Wwp'; 'Wwi'; 'Ri'}; 
metaData.data_1     = {'t-WwYe'; 't-WwVe'; 't-JOe'}; 

metaData.COMPLETE = 2.7; % using criteria of LikaKear2011

metaData.author   = {'Bas Kooijman'};    
metaData.date_subm = [2011 11 12];              
metaData.email    = {'bas.kooijman@vu.nl'};            
metaData.address  = {'VU University, Amsterdam'}; 

metaData.curator     = {'Starrlight Augustine'};
metaData.email_cur   = {'starrlight@akvaplan.niva.no'}; 
metaData.date_acc    = [2015 09 21];


%% set data
% zero-variate data

data.ab = 65;        units.ab = 'd';    label.ab = 'age at birth';             bibkey.ab = 'crocodilian';   
  temp.ab = C2K(30); units.temp.ab = 'K'; label.temp.ab = 'temperature';
  comment.ab = '74-80 d, depending on temperature';
data.ap = 365*12.5;  units.ap = 'd';    label.ap = 'age at puberty for female';bibkey.ap = 'Whit1987';
  temp.ap = C2K(22); units.temp.ap = 'K'; label.temp.ap = 'temperature';
data.apm = 365*16.5; units.apm = 'd';   label.apm = 'age at puberty for male'; bibkey.apm = 'Whit1987';
  temp.apm = C2K(22);units.temp.apm = 'K'; label.temp.apm = 'temperature';
data.am = 50 * 365;  units.am = 'd';    label.am = 'life span';                bibkey.am = 'Whit1987';   
  temp.am = C2K(22); units.temp.am = 'K'; label.temp.am = 'temperature'; 

data.Lb  = 24;       units.Lb  = 'cm';  label.Lb  = 'total length at birth';   bibkey.Lb  = 'Whit1987';  
data.Lp  = 76 * 150/87; units.Lp  = 'cm';  label.Lp  = 'total length at puberty'; bibkey.Lp  = 'crocodilian'; 
data.Lpm  = 150;     units.Lpm  = 'cm'; label.Lpm  = 'total length at puberty';bibkey.Lpm  = 'crocodilian'; 
  comment.Lp = '150 cm total length = 87 cm snout-to-vent';
data.Li  = 200;      units.Li  = 'cm';  label.Li  = 'ultimate total length for female'; bibkey.Li  = 'Wiki';
data.Lim  = 300;     units.Lim  = 'cm'; label.Lim  = 'ultimate total length for male'; bibkey.Lim  = 'Wiki';

data.Wwb = 42;       units.Wwb = 'g';   label.Wwb = 'wet weight at birth';     bibkey.Wwb = 'Whit1987';
data.Wwp = 7480;     units.Wwp = 'g';   label.Wwp = 'wet weight at puberty';   bibkey.Wwp = 'guess';
  comment.Wwp = 'Computed as Wwi*(Lp/Li)^3';
data.Wwpm = 11250;   units.Wwpm = 'g';  label.Wwpm = 'wet weight at puberty';  bibkey.Wwpm = 'guess';
  comment.Wwpm = 'Computed as Wwim*(Lp/Lim)^3 = 90*(1.5/3)^3';
data.Wwi = 26600;    units.Wwi = 'g';   label.Wwi = 'ultimate wet weight of female'; bibkey.Wwi = 'Wiki';
  comment.Wwi = 'Computed as Wwim*(Li/Lim)^3 = 90*(2/3)^3; Wiki: upto 40 kg';
data.Wwim = 90000;   units.Wwim = 'g';  label.Wwim = 'ultimate wet weight of male';  bibkey.Wwim = 'Wiki';
  comment.Wwim = 'Wiki: upto 100 kg';  

data.Ri  = 13/365;   units.Ri  = '#/d'; label.Ri  = 'maximum reprod rate';     bibkey.Ri  = 'Whit1987';   
  temp.Ri = C2K(22); units.temp.Ri = 'K'; label.temp.Ri = 'temperature';
 
% uni-variate data
% age-yolk-free wet weight
data.aW = [  ... % time (d), wet weight (g)
      20 0.4414841685;
      20.01 0.7857969114;
      23 0.5181908172;
      23.01 0.7286161847;
      27 0.6523986401;
      27.01 0.9202155552;
      30 1.264809392;
      30.01 1.456093937;
      31 0.9205050823;
      34 1.705090477;
      35 2.1259637;
      39 2.126250416;
      39.01 2.527985627;
      41 2.642900836;
      42 3.006435919;
      43 3.255235693;
      47 4.422443586;
      47.01 5.015454908;
      50 6.067789756;
      51 6.584358659;
      51.01 6.450493771;
      51.02 5.972251488;
      56 7.560335414;
      56.01 8.956774995;
      61 10.33448977;
      61.01 11.48225607;
      61.02 12.32397722;
      65 16.41803597;
      66 18.1205966;
      67 16.43725269;
      70 20.43561577;
      71 18.40790852;
      71.01 24.95026103;
      73 20.43581254;
      73.01 21.3731872;
      76 24.52976167;
      76.01 26.34707166;
      76.02 27.59048585;
      77 28.64271669;
      78 27.11243471;
      81 26.82567374;
      81.01 29.92467114;
      81.02 30.70899512;
      81.03 32.43067689;
      83 27.72493542;
      84 30.57534948;
      85 33.50223408;
      86 32.96664803;
      89 38.64838032];
units.aW   = {'d', 'g'};  label.aW = {'age', 'yolk-free wet weight'};  
temp.aW    = C2K(30);  units.temp.aW = 'K'; label.temp.aW = 'temperature';
bibkey.aW = {'Whit1987','WhitWebb1990'};

% age-yolk wet weight
data.aWY = [ ... % time (d), wet weight (g)
      20 27.26517524;
      20.01 25.73740821;
      20.02 20.42602386;
      22 26.19091619;
      22.01 24.93047731;
      22.02 24.20273913;
      24 24.41616013;
      25 24.33984325;
      25.01 25.55224173;
      26 25.64590682;
      26.01 27.02794215;
      27 27.00116113;
      29 25.41707124;
      30 22.98824808;
      31 25.33833864;
      35 26.95160332;
      36 24.01179898;
      49 22.87958463;
      50 22.43893853;
      59 21.51291997;
      71 17.47469939;
      72 14.68131694;
      73 16.88625098;
      73.01 15.4313498;
      75 15.44731761;
      75.01 10.79126572;
      76 9.140176729;
      77 9.353712757;
      79 14.31880631;
      80 7.113600189;
      81 8.103950105;
      81.01 6.940052167;
      82 15.54728762;
      83 11.32555495;
      86 11.38645723;
      86.01 10.70917518;
      86.02 8.646751867;
      86.03 2.777611299;
      88 7.233679241;
      92 7.65568979;
      93 8.286196816;
      94 9.178970479;
      95 10.60686057;
      95.01 4.957237807];
units.aWY   = {'d', 'g'};  label.aWY = {'age', 'yolk wet weight'};  
temp.aWY    = C2K(30);  units.temp.aWY = 'K'; label.temp.aWY = 'temperature';
bibkey.aWY = {'Whit1987','WhitWebb1990'};

% age-respiration
data.aJO = [ ... % time (d), O_2 consumption ml/d
       16.1166646  0.05838195376;
       16.60740707 0.04924563988;
       17.87420151 0.05222414374;
       20.77630776 0.06912590549;
       21.16779633 0.1232631577;
       21.53403464 0.1217070323;
       21.59663479 0.094858705;
       22.29783158 0.1080417773;
       22.68227167 0.1222967784;
       22.93731909 0.08229530719;
       23.90987817 0.1104012213;
       24.46371759 0.1440885272;
       24.58696813 0.1775546783;
       25.67285662 0.1298184718;
       25.67981694 0.09869193232;
       26.51545282 0.140450402;
       26.52067307 0.1171054974;
       26.79419145 0.1535052658;
       27.76743394 0.1416099931;
       28.48402408 0.1540180999;
       28.63006371 0.1307159315;
       29.46105937 0.1932254275;
       29.61684235 0.1696996822;
       30.16747641 0.1830635952;
       30.52880531 0.141668383;
       32.8825354  0.2298319598;
       32.89520983 0.2089616892;
       32.91809465 0.1631459243;
       33.14044346 0.2779810185;
       33.49239271 0.1140331814;
       34.08352559 0.2617639708;
       34.25367154 0.2180101209;
       34.31584801 0.2102630952;
       34.33440889 0.1272589899;
       34.3355759  0.2013507636;
       34.89768643 0.1274299346;
       35.01240458 0.2441971939;
       35.03421239 0.2330247608;
       35.56060141 0.3118089741;
       37.71691482 0.3074713546;
       38.30877754 0.2785478489;
       38.55515664 0.4605788645;
       38.56849727 0.4009196638;
       38.63774691 0.4061287884;
       39.41921386 0.3752372979;
       39.43603465 0.3000148275;
       39.67737879 0.2709000642;
       39.69447233 0.4038554315;
       39.94862344 0.2119725422;
       40.00453244 0.2768408675;
       41.0112796  0.4385994112;
       41.03916336 0.392684816;
       42.64666101 0.4644914958;
       43.00395427 0.7187403729;
       43.06427712 0.4489770306;
       43.07900418 0.6980107146;
       43.50297604 0.3764766469;
       44.32723775 0.7839933238;
       44.45855032 0.5116574713;
       44.47131092 0.4545921489;
       44.5302904  0.4362314545;
       44.68728244 0.5323452764;
       44.69146679 0.7296287201;
       44.72626843 0.5739960226;
       45.10060658 0.4427874087;
       45.11708335 0.415656057;
       45.14702253 0.4845648089;
       45.15716208 0.4678685925;
       47.78253295 0.7616954554;
       47.84946247 0.7772800932;
       47.8628031  0.7176208926;
       48.04944465 0.5127472437;
       48.40519966 0.8111714557;
       48.56435354 0.4143294453;
       49.40426908 0.685080786;
       49.53306885 0.5912014277;
       49.7352094  0.7311796769;
       50.30626137 0.8117483941;
       50.67107043 0.7547899121;
       50.95140891 0.7380673633;
       51.00107786 0.8534641276;
       51.62771089 0.6883104462;
       51.6370852  0.8432809272;
       52.73602535 1.282009616;
       54.12891212 1.035997172;
       54.14660459 0.7960757546;
       55.105141   0.7639177364;
       55.21138512 1.233473811;
       55.28343463 0.8154487442;
       55.2914289  0.8755186072;
       55.79902381 1.124701868;
       56.09343521 1.018369537;
       57.43665398 1.358663748;
       57.58655443 1.042100877;
       57.61776106 1.108922601;
       57.63677271 1.077617196;
       58.69996825 1.377205522;
       58.83882118 1.071149251;
       58.93741147 1.063671471;
       59.09261864 1.195740882;
       59.16157802 1.049172859;
       59.26280256 1.237115871;
       59.28260219 1.322720839;
       59.3603957  1.076414788;
       60.03659236 1.382799272;
       60.07197403 1.224572696;
       60.43932959 1.471119342;
       60.53619416 1.037941668;
       60.65577891 1.447838542;
       60.85076723 1.520531238;
       60.94843821 1.398640327;
       61.19332734 1.131635829;
       61.25037794 1.307940059;
       61.272999   1.206778806;
       61.88768205 1.288568308;
       62.12626993 1.132114997;
       62.72282756 1.650802091;
       63.21730107 1.581526137;
       63.37984235 1.55029445;
       63.6578745  1.562888015;
       63.72735052 1.881977781;
       63.75171167 1.773034892;
       64.02094348 1.513711167;
       64.03138398 1.467021358;
       64.27017132 1.502735137;
       65.09712812 1.559527177;
       65.58932401 1.742463923;
       65.9017504  1.534888303;
       66.0795181  2.069463532;
       66.26722022 1.760545239;
       66.42982648 2.077352008;
       66.51531689 2.00993254;
       66.84532431 2.108606756;
       66.87840311 1.936224103;
       66.99644629 1.38722541;
       67.07232196 1.616908963;
       67.09989719 1.335086593;
       67.37380255 1.475101701;
       67.64644047 1.617203836;
       67.84429923 1.882440568;
       67.87978764 1.82400381;
       67.99762698 2.308698642;
       68.11189238 1.797704618;
       68.13485229 1.640419148;
       68.19934924 2.036384157;
       68.59245238 2.4826808;
       68.72291269 1.617756723;
       68.75617474 1.799401795;
       68.81146279 1.826570006;
       68.88314521 2.127383578;
       68.96989322 1.565691624;
       69.06731542 1.759895718;
       69.369584   1.73499883;
       69.69325988 2.283272693;
       69.70950065 2.210644101;
       69.83153278 1.979810301;
       69.92976064 1.758251;
       69.94705734 2.407864323;
       70.18688071 1.689489685;
       70.44398538 2.389856752;
       70.62253937 1.681362732;
       70.7195975  2.102000366;
       71.25816024 2.527588718;
       71.34458432 2.141100853;
       71.77632292 2.099727009;
       72.13555809 2.382587951;
       72.36106147 2.003924457;
       72.52646839 2.208904946;
       72.99555512 2.315403532;
       73.31048183 2.481518583;
       73.3290427  2.398514478;
       73.33600303 2.367387939;
       73.34064325 2.346636912;
       73.47552533 2.302868428;
       73.56637302 2.281854059;
       73.59711447 2.14437851;
       74.53315683 1.979821544;
       75.2828869  2.163048492;
       75.63244303 1.942807944;
       75.88370535 1.765484362;
       76.21410003 2.407172205;
       76.96946574 2.493005237;
       77.14046305 1.705587183;
       77.49736162 2.651402758;
       77.95926164 2.475147242;
       78.29564936 2.545288797;
       78.59468895 2.46755792;
       78.98843308 2.090669076;
       79.26282418 2.628592055;
       79.53641474 2.015794116;
       79.55035662 1.992836818;
       79.57443805 1.953183304;
       80.02989634 2.030661319;
       80.09127335 2.387596423;
       80.42998119 2.447362464;
       80.84989285 2.143985545;
       81.17874022 2.247847517;
       81.42179103 1.866449646;
       81.78726084 2.092106582;
       81.91728515 2.40890302;
       82.02887678 2.224759029;
       82.1358282  2.061366065;
       82.15526554 2.313589464;
       82.17062984 1.905733367;
       82.29056824 1.999155722;
       82.39890609 2.144455642;
       82.54401205 2.440221872;
       82.73297371 2.22497271;
       82.87640749 2.071789198;
       83.26934361 2.030581415;
       83.33265377 2.266177587;
       83.41038938 2.344504792;
       83.44576476 2.316339955;
       83.45969171 2.124025137;
       83.56303569 2.606550604;
       83.75177097 2.077420801;
       84.04095035 2.400152769;
       84.15930205 2.087061852;
       84.48045543 2.282572235;
       84.61602779 2.16245284;
       84.72485698 2.33787369;
       85.23524112 2.370999145;
       85.23639131 2.55943029;
       85.23791488 2.044149113;
       85.32282525 1.979323523;
       85.32943193 2.264671504;
       86.20102951 2.145609519;
       86.20544335 1.810977852;
       86.25439203 1.906972716;
       86.43545968 2.041918492;
       87.09182842 2.341177068;
       87.11612913 1.832006663;
       87.21620881 1.78174324;
       87.47652436 2.109679849;
       87.56201477 2.042260381;
       87.8256448  2.078506532;
       87.82834644 1.795906048;
       87.93958443 1.928236577;
       88.1908354  1.749323079;
       88.26901183 2.029504671;
       88.43941261 1.897259614;
       88.7601396  2.037435882;
       88.77592761 1.337046007;
       88.83728324 1.692450069;
       89.15814059 1.657479954;
       89.26412637 1.601167083;
       90.85370888 2.057097318;
       90.88080465 1.894272349;
       91.73184288 1.911410875;
       92.97465871 1.874470993;
       93.08571427 1.809810014;
       93.20677179 1.137639866;
       93.25174935 1.53640947;
       93.50664307 1.707729984;
       93.60992303 2.010496343];
data.aJO(:,2) = data.aJO(:,2) * 100; % convert to ml/d
units.aJO   = {'d', 'ml/d'};  label.aJO = {'age', 'O2 consumption'};  
temp.aJO    = C2K(30);  units.temp.aJO = 'K'; label.temp.aJO = 'temperature';
bibkey.aJO = {'Whit1987','WhitWebb1990'};
  
%% set weights for all real data
weights = setweights(data, []);
weights.aJO = 10 * weights.aJO;

%% set pseudodata and respective weights
[data, units, label, weights] = addpseudodata(data, units, label, weights);

%% pack auxData and txtData for output
auxData.temp = temp;
txtData.units = units;
txtData.label = label;
txtData.bibkey = bibkey;
txtData.comment = comment;

%% Discussion points
D1 = 'Males are assumed to differ from females by {p_Am} only';
metaData.discussion = struct('D1', D1);

%% Facts
F1 = 'temperature effects have shown that eggs incubated at 32 C produce male embryos, whereas those a couple of degrees above and below this produce female embryos';
metaData.bibkey.F1 = 'crocodilian'; 
metaData.facts = struct('F1',F1);

%% Links
metaData.links.id_CoL = '6BHQR'; % Cat of Life
metaData.links.id_ITIS = '551774'; % ITIS
metaData.links.id_EoL = '795282'; % Ency of Life
metaData.links.id_Wiki = 'Crocodylus_johnsoni'; % Wikipedia
metaData.links.id_ADW = 'Crocodylus_johnsoni'; % ADW
metaData.links.id_Taxo = '50631'; % Taxonomicon
metaData.links.id_WoRMS = '1041088'; % WoRMS
metaData.links.id_ReptileDB = 'genus=Crocodylus&species=johnsoni'; % ReptileDB
metaData.links.id_AnAge = 'Crocodylus_johnsoni'; % AnAge


%% References
bibkey = 'Wiki'; type = 'Misc'; bib = ...
'howpublished = {\url{http://en.wikipedia.org/wiki/Crocodylus_johnsoni}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Kooy2010'; type = 'Book'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Kooijman, S.A.L.M.}, ' ...
'year = {2010}, ' ...
'title  = {Dynamic Energy Budget theory for metabolic organisation}, ' ...
'publisher = {Cambridge Univ. Press, Cambridge}, ' ...
'pages = {Table 4.2 (page 150), 8.1 (page 300)}, ' ...
'howpublished = {\url{../../../bib/Kooy2010.html}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Whit1987'; type = 'Incollection'; bib = [ ... 
'author = {P. J. Whitehead}, ' ... 
'year = {1987}, ' ...
'title = {Respiration of \emph{Crocodylus johnstoni} embryos}, ' ...
'booktitle = {Crocodiles and Alligators}, ' ...
'editor = {G. J. W. Webb and S. C. Manolis and P. J. Whitehead}, ' ...
'publisher = {Beatty} , ' ...
'address = {Sydney}, ' ...
'pages = {473--497}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'WhitWebb1990'; type = 'Article'; bib = [ ... 
'author = {P. J. Whitehead and G. J. W. Webb and R. S. Seymour}, ' ... 
'year = {1990}, ' ...
'title = {Effect of incubation temperature on development of \emph{Crocodylus johnstoni} embryos}, ' ...
'journal = {Physiol. Zool.}, ' ...
'volume = {63}, ' ...
'pages = {949--964}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Brit'; type = 'Misc'; bib = [...
'author = {Adam Britton}, ' ... 
'howpublished = {\url{http://www.kingsnake.com/oz/crocs/johnstoni.htm}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'crocodilian'; type = 'Misc'; bib = ...
'howpublished = {\url{http://crocodilian.com/cnhc/csp_cjoh.htm}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];

