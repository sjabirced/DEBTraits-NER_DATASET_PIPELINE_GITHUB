function [prdData, info] = predict_Thunnus_thynnus(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);

  % compute temperature correction factors
  TC = tempcorr(temp.ap, T_ref, T_A);
  TC_ab = tempcorr(C2K(Tab(:,1)), T_ref, T_A);
  
  % zero-variate data

  % life cycle
  pars_tj = [g k l_T v_Hb v_Hj v_Hp];
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tj, f);
  
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Lw_b = L_b/ del_M;                % cm, physical length at birth at f

  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Lw_p = L_p/ del_M;                % cm, physical length at puberty at f
  aT_p = t_p/ k_M/ TC;              % d, age at puberty at f and T

  % ultimate
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate physical length at f

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC;                  % d, mean life span at T
  
  % pack to output
  prdData.ap = aT_p;
  prdData.am = aT_m;
  prdData.Lb = Lw_b;
  prdData.Lp = Lw_p;
  prdData.Li = Lw_i;

  % uni-variate data
  
  % Tab-data
  Eab = t_b/ k_M ./ TC_ab; % d, age at birth 
  
  % time-length 
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B] = get_tj(pars_tj, f_tL);
  kT_M = k_M * TC; rT_j = rho_j * kT_M; rT_B = rho_B * kT_M;        
  L_b = L_m * l_b;  L_j = L_m * l_j; L_i = L_m * l_i; tT_j = (t_j - t_b)/ kT_M;
  L_bj = L_b * exp(tL_lrv((tL_lrv(:,1) <= tT_j),1) * rT_j/ 3);
  L_jm = L_i - (L_i - L_j) * exp( - rT_B * (tL_lrv((tL_lrv(:,1) > tT_j),1) - tT_j)); % cm, expected length at time
  ELw_lrv = [L_bj; L_jm]/ del_M; % cm, total length 
  %
  L_bj = L_b * exp(tL_juv((tL_juv(:,1) <= tT_j),1) * rT_j/ 3);
  L_jm = L_i - (L_i - L_j) * exp( - rT_B * (tL_juv((tL_juv(:,1) > tT_j),1) - tT_j)); % cm, expected length at time
  ELw_juv = [L_bj; L_jm]/ del_M;                                            % cm, total length     
  %
  L_bj = L_b * exp(tL_adt((tL_adt(:,1) <= tT_j),1) * rT_j/ 3);
  L_jm = L_i - (L_i - L_j) * exp( - rT_B * (tL_adt((tL_adt(:,1) > tT_j),1) - tT_j)); % cm, expected length at time
  ELw_adt = [L_bj; L_jm]/ del_M;                                            % cm, total length     
  %
  L_bj = L_b * exp(tW((tW(:,1) <= tT_j),1) * rT_j/ 3);
  L_jm = L_i - (L_i - L_j) * exp( - rT_B * (tW((tW(:,1) > tT_j),1) - tT_j)); % cm, expected length at time
  EWw = [L_bj; L_jm] .^3 * (1 + f * w);                                      % g, wet weight   
  
  % length-weight
  EWw_L = (LW(:,1) * del_M).^3 * (1 + f * w);                  % g, expected wet weight at time

  % LN-data
  L = L_i - (L_i - L_j) * exp( - rT_B * (tN(:,1) - tT_j)); % cm, expected length at time
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hj; U_Hp]; % compose parameter vector at T
  EN = TC * 365e-6 * reprod_rate_j(L, f, pars_R); % 1e6, eggs fecundity

  % pack to output
  prdData.Tab = Eab;
  prdData.tL_lrv = ELw_lrv;
  prdData.tL_juv = ELw_juv;
  prdData.tL_adt = ELw_adt;
  prdData.tW = EWw;
  prdData.LW= EWw_L;
  prdData.tN = EN;