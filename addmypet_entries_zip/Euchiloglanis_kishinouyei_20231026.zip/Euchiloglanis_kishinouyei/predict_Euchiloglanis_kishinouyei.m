function [prdData, info] = predict_Euchiloglanis_kishinouyei(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
 
  
  %% compute temperature correction factors
  TC = tempcorr(temp.am, T_ref, T_A); kT_M = TC * k_M;
  TC_ab = tempcorr(temp.ab, T_ref, T_A);

  % life cycle
  pars_tj = [g k l_T v_Hb v_Hj v_Hp];
  [tau_j, tau_p, tau_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tj, f);

  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth of foetus  at f = 1
  Ww_b = L_b^3 * (1 + f * ome);     % g, wet weight at birth
  aT_b = tau_b/ k_M/ TC_ab;         % d, age at birth            

  % metam
  s_M = l_j/l_b;                    % -, acceleration factor
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Lw_p = L_p/ del_M;                % cm, total length at puberty at f
  Ww_p = L_p^3 * (1 + f * ome);     % g, wet weight at puberty
  tT_p = (tau_p - tau_b)/ kT_M;     % d, time since birth at puberty

  % ultimate
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate total length at f
  Ww_i = L_i^3 * (1 + f * ome);     % g, ultimate wet weight

  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hj; U_Hp]; % compose parameter vector
  
  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ kT_M;                     % d, mean life span at T
  
  % pack to output
  prdData.ab = aT_b;
  prdData.am = aT_m;
  prdData.Lp = Lw_p;
  prdData.Li = Lw_i;
  prdData.Wwb = Ww_b;
  prdData.Wwp = Ww_p;
  prdData.Wwi = Ww_i;

  %% uni-variate data
  
  % time-length
  tf = [1000 f_1000; 2000 f_2000];tf(:,1) =  tf(:,1) * kT_M;
  tvel = get_tj(pars_tj, tf ,[tau_b 1 l_b], tLW(:,1)*kT_M);
  ELw = L_m*tvel(:,4)/ del_M; % cm, std length 
  EWw = (L_m*tvel(:,4)).^3.*(1+tvel(:,3)*ome); % g, weight

  % length-weight
  EWw_L = (LW(:,1)*del_M).^3*(1+f_2000*ome); % g, weight
  
  % length-fecundity
  EN_L = TC * 365 * reprod_rate_j(LN(:,1)*del_M, f_2000, pars_R); % #, yearly fecundity
  
  % weight-fecundity
  EN_W = TC * 365 * reprod_rate_j((WN(:,1)/(1+f_2000*ome)).^(1/3), f_2000, pars_R); % #, yearly fecundity
  
  % pack to output
  prdData.tLW = [ELw EWw];
  prdData.LW = EWw_L;
  prdData.LN = EN_L;
  prdData.WN = EN_W;
  
end