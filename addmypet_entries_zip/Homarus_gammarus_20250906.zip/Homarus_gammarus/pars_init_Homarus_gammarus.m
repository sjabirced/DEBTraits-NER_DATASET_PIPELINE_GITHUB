function [par, metaPar, txtPar] = pars_init_Homarus_gammarus(metaData)

metaPar.model = 'abj'; 

%% reference parameter (not to be changed) 
par.T_ref = 293.15;   free.T_ref = 0;   units.T_ref = 'K';        label.T_ref = 'Reference temperature'; 

%% core primary parameters 
par.z = 7.056;        free.z     = 1;   units.z = '-';            label.z = 'zoom factor for females'; 
par.z_male = 8.952;   free.z_male     = 1;   units.z_male = '-';            label.z_male = 'zoom factor for females'; 
par.F_m = 6.5;        free.F_m   = 0;   units.F_m = 'dm²/d.cm^2';   label.F_m = '{F_m}, max spec searching rate'; 
par.kap_X = 0.8;      free.kap_X = 0;   units.kap_X = '-';        label.kap_X = 'digestion efficiency of food to reserve'; 
par.kap_P = 0.1;      free.kap_P = 0;   units.kap_P = '-';        label.kap_P = 'faecation efficiency of food to faeces'; 
par.v = 0.04747;       free.v     = 1;   units.v = 'cm/d';         label.v = 'energy conductance'; 
par.kap = 0.8218;    free.kap   = 1;   units.kap = '-';          label.kap = 'allocation fraction to soma'; 
par.kap_R = 0.95;     free.kap_R = 0;   units.kap_R = '-';        label.kap_R = 'reproduction efficiency'; 
par.p_M = 15.51;    free.p_M   = 1;   units.p_M = 'J/d.cm^3';   label.p_M = '[p_M], vol-spec somatic maint'; 
par.p_T = 0;          free.p_T   = 0;   units.p_T = 'J/d.cm^2';   label.p_T = '{p_T}, surf-spec somatic maint'; 
par.k_J = 0.002;      free.k_J   = 0;   units.k_J = '1/d';        label.k_J = 'maturity maint rate coefficient'; 
par.E_G = 4400;       free.E_G   = 0;   units.E_G = 'J/cm^3';     label.E_G = '[E_G], spec cost for structure'; 
par.E_Hb = 7.103; free.E_Hb  = 1;   units.E_Hb = 'J';         label.E_Hb = 'maturity at birth'; 
par.E_Hj = 55.2; free.E_Hj  = 1;   units.E_Hj = 'J';         label.E_Hj = 'maturity at metam'; 
par.E_Hp = 2.369e+05; free.E_Hp  = 1;   units.E_Hp = 'J';         label.E_Hp = 'maturity at puberty'; 
par.h_a = 1.99e-09;  free.h_a   = 1;   units.h_a = '1/d^2';      label.h_a = 'Weibull aging acceleration'; 
par.s_G = 0.0001;     free.s_G   = 0;   units.s_G = '-';          label.s_G = 'Gompertz stress coefficient'; 


%% Environmental response
%Temp
par.T_A = 8000;     free.T_A   = 0;   units.T_A = 'K';          label.T_A = 'Arrhenius temperature'; 
par.T_H = 295;      free.T_H   = 0;  units.T_H = 'K';          label.T_H = 'upper boundary';
par.T_L = 275;      free.T_L   = 0;   units.T_L = 'K';          label.T_L = 'lower boundary'; 
par.T_AH = 1e5;     free.T_AH  = 0;   units.T_AH = 'K';         label.T_AH = 'Arrhenius temperature at upper boundary'; 
par.T_AL = 1e5;     free.T_AL  = 0;   units.T_AL = 'K';         label.T_AL = 'Arrhenius temperature at lower boundary';  
par.T_AHf = 1e5;    free.T_AHf  = 0;   units.T_AHf = 'K';         label.T_AHf = 'Arrhenius temperature at upper boundary'; 
par.T_Hf = 295;     free.T_Hf  = 0;   units.T_Hf = 'K';          label.T_Hf = 'upper boundary'; 

%Sal
par.S_L = 8;        free.S_L   = 0;   units.S_L = 'psu';          label.S_L = 'Lower salinity boundary'; 
par.S_H = 20;       free.S_H   = 0;   units.S_H = 'psu';          label.S_H = 'Upper salinity boundary, guess'; 

% Food
par.f = 1;            free.f     = 0;   units.f = '-';            label.f = 'scaled functional response for 0-var data'; 
par.f_aq = 0.9;       free.f_aq  = 0;   units.f_aq = '-';         label.f_aq= 'scaled functional response for 0-var data'; 
par.f_wild = 0.5853;       free.f_wild  = 1;   units.f_wild = '-';         label.f_wild= 'scaled functional response for 0-var data'; 

%% other parameters 
par.del_M = 0.7601;   free.del_M = 1;    units.del_M = '-';         label.del_M = 'shape coefficient carapace'; 
par.t_0 = 301;   free.t_0   = 1;   units.t_0 = 'd';          label.t_0 = 'time at start development'; 
par.day_spwn = 180;   free.day_spwn = 1; units.day_spwn = 'd';    label.day_spwn = 'day of spawning';
par.TL2CL = 0.35;     free.TL2CL = 0;    units.TL2CL = 'cm/cm';        label.TL2CL = 'Carapace length to total length conversion';
    % REF: Development of methods for intensive farming of European lobster
    % in recirculated seawater, Kristiansen et al., 2004


%% set chemical parameters from Kooy2010 
[par, units, label, free] = addchem(par, units, label, free, metaData.phylum, metaData.class); 

%% Pack output: 
txtPar.units = units; txtPar.label = label; par.free = free; 
