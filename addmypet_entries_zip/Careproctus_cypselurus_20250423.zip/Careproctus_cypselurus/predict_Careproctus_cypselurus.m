function [prdData, info] = predict_Careproctus_cypselurus(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
        
  % compute temperature correction factors
  TC    = tempcorr(temp.am, T_ref, T_A); kT_M = TC * k_M;

  % zero-variate data

  % life cycle
  pars_tj = [g k l_T v_Hb v_Hj v_Hp];
  [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tj, f);

  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Lw_b = L_b/ del_M;                % cm, physical length at birth at f
  aT_b = t_b/ kT_M;                 % d, age at birth at f and T
  Ww_b = L_b^3 * (1 + f * ome);     % g, weight at birth
  
  % metam
  L_j = L_m * l_j;                  % cm, structural length at metam
  Lw_j = L_j/ del_M;                % cm, physical length at metam
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  Lw_p = L_p/ del_M;                % cm, physical length at puberty at f
  Ww_p = L_p^3 * (1 + f * ome);     % g, weight at puberty

  % ultimate
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Lw_i = L_i/ del_M;                % cm, ultimate physical length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 
 
  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ kT_M;                     % d, mean life span at T

  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hj; U_Hp]; % compose parameter vector at T
  RT_i =  TC * reprod_rate_j(L_i, f, pars_R); % #/d, ultimate reproduction rate at T

%   % males
%   p_Amm = z_m * p_M/ kap;              % J/d.cm^2, {p_Am} max spec assimilation flux for males
%   E_mm = p_Amm/ v;                     % J/cm^3, [E_m] reserve capacity for males
%   g_m = E_G/ kap/ E_mm;                % -, energy investment ratio for males
%   m_Emm = y_E_V * E_mm/ E_G;           % mol/mol, reserve capacity 
%   ome_m = m_Emm * w_E/ w_V;              % -, contribution of reserve to weight
%   L_mm = v/ k_M/ g_m;                  % cm, maximum structural length for males
%   pars_tjm = [g_m k l_T v_Hb v_Hj v_Hp];
%   [t_j, t_p, t_b, l_j, l_p, l_b, l_i, rho_j, rho_B, info] = get_tj(pars_tjm, f);
%   Lw_pm = l_p * L_mm/ del_M; Lw_im =  l_i * L_mm/ del_M;   % cm, total length at puberty, ulitmate for male
  
  % pack to output
  prdData.ab = aT_b;
  prdData.am = aT_m;
  prdData.Lp = Lw_p;
  prdData.Li = Lw_i;
  prdData.Wwb = Ww_b;
  prdData.Wwp = Ww_p;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;
   
  % uni-variate data
  
  % time-length-weight 
  tvel = get_tj(pars_tj, f_tL, [], tLW(:,1)*kT_M);
  L = L_m * tvel(:,4); ELw = L/ del_M;
  EWw = L.^3 .* (1 + ome * tvel(:,3)); % g, weight 
 
  % pack to output
  prdData.tLW = [ELw EWw];
  