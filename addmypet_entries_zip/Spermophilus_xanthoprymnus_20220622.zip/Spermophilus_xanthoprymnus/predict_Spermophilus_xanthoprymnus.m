function [prdData, info] = predict_Spermophilus_xanthoprymnus(par, data, auxData)
  
  % unpack par, data, auxData
  cPar = parscomp_st(par); vars_pull(par); 
  vars_pull(cPar);  vars_pull(data);  vars_pull(auxData);
  
  if f_130 < 0.5 || f_300 < 0.5
      info = 0; prdData = []; return
  end
  
  % compute temperature correction factors
  TC = tempcorr(temp.tg, T_ref, T_A);
  
  % zero-variate data

  % life cycle
  pars_tx = [g k l_T v_Hb v_Hx v_Hp]; 
  [t_p, t_x, t_b, l_p, l_x, l_b, info] = get_tx(pars_tx, f);
  if ~info
    prdData = []; return
  end
 
  % birth
  L_b = L_m * l_b;                  % cm, structural length at birth at f
  Ww_b = L_b^3 * (1 + f * w);       % g, wet weight at birth at f 
  tT_g = t_0 + t_b/ k_M/ TC;        % d, gestation time at f and T

  % weaning
  L_x = L_m * l_x;                  % cm, structural length at weaning
  Ww_x = L_x^3 * (1 + f * w);       % g, wet weight at weaning
  tT_x = (t_x - t_b)/ k_M/ TC;      % d, time since birth at fledging at f and T
  
  % puberty 
  L_p = L_m * l_p;                  % cm, structural length at puberty at f
  tT_p = (t_p - t_b)/ k_M/ TC;      % d, time since birth at puberty at f and T

  % ultimate
  l_i = f - l_T;                    % -, scaled ultimate length
  L_i = L_m * l_i;                  % cm, ultimate structural length at f
  Ww_i = L_i^3 * (1 + f * w);       % g, ultimate wet weight 

  % reproduction
  pars_R = [kap; kap_R; g; k_J; k_M; L_T; v; U_Hb; U_Hp]; % compose parameter vector at T
  RT_i = TC * reprod_rate_foetus(L_i, f, pars_R);         % #/d, ultimate reproduction rate at T

  % life span
  pars_tm = [g; l_T; h_a/ k_M^2; s_G];  % compose parameter vector at T_ref
  t_m = get_tm_s(pars_tm, f, l_b);      % -, scaled mean life span at T_ref
  aT_m = t_m/ k_M/ TC;                  % d, mean life span at 
  
  % pack to output
  prdData.tg = tT_g;
  prdData.tx = tT_x;
  prdData.tp = tT_p;
  prdData.am = aT_m;
  prdData.Wwb = Ww_b;
  prdData.Wwi = Ww_i;
  prdData.Ri = RT_i;
  
  % uni-variate data
  
  % time-weight
  tf = [0 f_000; 100 f_100; 130 f_130; 300 f_300; 370 f_370]; % scaled func response in time
  [t, Le] = ode45(@get_Le, [0; tWw_f(:,1)], [L_b; 1], [], tf, v * TC, g, L_m);
  Le(1,:) = []; EWw_f = Le(:,1).^3 .* (1 + Le(:,2) * w);  % g, wet weight
  %
  [t, Le] = ode45(@get_Le, [0; tWw_m(:,1)], [L_b; 1], [], tf, v * TC, g, L_m);
  Le(1,:) = []; EWw_m = Le(:,1).^3 .* (1 + Le(:,2) * w); % g, wet weight
  
  % pack to output
  prdData.tWw_f = EWw_f;
  prdData.tWw_m = EWw_m;

end

function dLe = get_Le(t, Le, tf, v, g, L_m)
  L = Le(1); e = Le(2);
  f = spline1(t, tf);
  de = (f - e) * v/ L;
  r = v * (e/L - 1/L_m)/ (e + g);
  dL = L * r/3;
  dLe = [dL; de];
end
  