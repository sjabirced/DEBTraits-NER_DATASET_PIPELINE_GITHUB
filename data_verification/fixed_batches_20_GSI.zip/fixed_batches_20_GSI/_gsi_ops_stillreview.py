#!/usr/bin/env python3
"""Hand-authored stage-2 GSI ops for the 18 still_needs_review species in the
fixed_batches_20_GSI_all_entities/*_manual_review/still_needs_review/ folders.

Only 2 of the 18 carry a GSI data record (audited here); the other 16 are non-GSI
taxa -> NO_GSI passthrough. The annotated text lives in the `result` field.

Provenance ("based on <species>") justifies an `approximately` qualifier.
"""

NEEDS_REVIEW = {}
REVIEW_NOTE = {}

OPS = {
 "Coryphaena_equiselis": [   # 0.055 -> 5.5%, T = 22.3
   ("r", "which averages 0.055 g/g",
        "The gonadosomatic index (GSI) averages 5.5% [GSI = 5.5%] in gravid females sampled at a water temperature of 22.3 °C [T = 22.3 °C]."),
   ("d", "defines a life-history axis oriented toward high reproductive turnover", None),
 ],
 "Scarus_frenatus": [   # 0.04 -> 4%, T = 28.2; prov (Hipposcarus_longiceps) -> approx; keep [Lp = 20 cm], [Wwp = 171.5 grams]
   ("r", "consistently register a gonadosomatic index of 0.04 g/g",
        "In controlled aquaria maintaining a temperature of 28.2 °C [T = 28.2 °C], gravid female Bridled parrotfish (Scarus frenatus) register a gonadosomatic index (GSI) of approximately 4% [GSI = approximately 4%]."),
   ("d", "equating to a gonad mass representing roughly 4% of total body mass", None),
   ("d", "likely reflects a strategic allocation of energy reserves that permits frequent, small-batch gamete release", None),
 ],
}
