#!/usr/bin/env python3
"""Self-contained GSI audit (v2 spec) for the 18 still_needs_review species in
fixed_batches_20_GSI_all_entities/*_manual_review/still_needs_review/.

The all-entities annotated text lives in the `result` field. Species with a GSI
data record -> REPAIRED (ops in _gsi_ops_stillreview.py); without -> NO_GSI
passthrough. Output <basename>_gsi_audit.json is written into each species folder.
No dependency on the (moved) shared engine files.
"""
import json, os, re, glob, importlib.util
from decimal import Decimal

HERE = os.path.dirname(os.path.abspath(__file__))
DVERIF = os.path.dirname(HERE)
ALLENT = os.path.join(DVERIF, "fixed_batches_20_GSI_all_entities")

_o = importlib.util.spec_from_file_location("opsstill", os.path.join(HERE, "_gsi_ops_stillreview.py"))
OSR = importlib.util.module_from_spec(_o); _o.loader.exec_module(OSR)
OPS = OSR.OPS

NUM = r"\d*\.\d+|\d+"
UNIT = (r"(?:grams? per gram|grammes? per gram|g\s*/\s*g|g per g(?:ram)?)"
        r"(?:\s+of\s+(?:total\s+)?(?:body\s+)?(?:mass|weight)|\s+of\s+somatic\s+(?:mass|tissue))?")
QUAL = r"(?:approximately|around|about|roughly|up to|nearly|~)\s+"
GSI_BR = re.compile(r"\[GSI = [^\]]*\]")
T_BR = re.compile(r"\[T = [^\]]*\]")
PROSE_RANGE = re.compile(r"(%s)\s*(?:to|through|–|—|-)\s*(%s)\s+(%s)" % (NUM, NUM, UNIT))
PROSE_ONE = re.compile(r"(%s)\s+(%s)" % (NUM, UNIT))
_SAFE = re.compile(r"^[0-9.eE*/+\-() ]+$")


def to_pct(v):
    v = str(v).strip()
    try:
        d = Decimal(v) * 100
    except Exception:
        if not _SAFE.match(v):
            raise ValueError("unsafe value %r" % v)
        d = Decimal(repr(eval(v, {"__builtins__": {}}, {}))) * 100
    s = format(d, "f")
    return s.rstrip("0").rstrip(".") if "." in s else s


def num_of(s):
    m = re.search(NUM, s); return m.group(0) if m else None

def conv_one(m):   return to_pct(m.group(1)) + "%"
def conv_range(m): return to_pct(m.group(1)) + "% to " + to_pct(m.group(2)) + "%"

def conv_br(m):
    inside = m.group(0)[len("[GSI = "):-1]
    qm = re.match(r"(%s)?(%s)" % (QUAL, NUM), inside)
    return m.group(0) if not qm else "[GSI = %s%s%%]" % (qm.group(1) or "", to_pct(qm.group(2)))

def stage1(t):
    return PROSE_ONE.sub(conv_one, PROSE_RANGE.sub(conv_range, GSI_BR.sub(conv_br, t)))

def cleanup(t):
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r" +\n", "\n", t); t = re.sub(r"\n +", "\n", t)
    t = re.sub(r" +([.,;:])", r"\1", t)
    return t.strip()

def split_sentences(text):
    out = []
    for para in text.split("\n\n"):
        for s in re.split(r"(?<=[.])\s+(?=[A-Z*])", para.strip()):
            if s.strip(): out.append(s.strip())
    return out


def gsi_record(spdir, sp):
    ent = json.load(open(os.path.join(spdir, sp + ".json"), encoding="utf-8"))
    return next((d for d in ent.get("data", []) if d.get("entity") == "GSI"), None)


def apply_ops(sp, txt):
    sents = split_sentences(txt)
    final = txt; repairs = []; edits = []
    for mode, anchor, new in OPS[sp]:
        matches = [s for s in sents if anchor in s]
        if len(matches) != 1:
            raise RuntimeError("anchor %r matched %d in %s" % (anchor, len(matches), sp))
        old = matches[0]
        if old not in final:
            raise RuntimeError("sentence gone for %r in %s" % (anchor, sp))
        if mode == "d":
            final = final.replace(" " + old, "", 1) if (" " + old) in final else final.replace(old, "", 1)
            edits.append({"sentence_before": old, "sentence_after": "", "inserted": "",
                "reason": "Removed an unsupported evaluative/DEB clause not grounded in the record."})
            continue
        final = final.replace(old, new, 1)
        ob, nb = GSI_BR.findall(old), GSI_BR.findall(new)
        ins_T = sorted(set(T_BR.findall(new)) - set(T_BR.findall(old)))
        inserted = ins_T[0] if ins_T else ""
        if ob:
            for o, n in zip(ob, nb):
                if o != n:
                    repairs.append({"entity": "GSI", "repair_mode": "value_unit_conversion",
                        "code": "UNIT-MISMATCH+VALUE-FORMAT", "before": o, "after": n, "sentence": new})
            reason = ("Converted GSI to a percentage (%s g/g x 100 = %s%%) and re-annotated the span; "
                      "rewrote in plain reproductive-biology register, dropping DEB/evaluative wording."
                      % (num_of(ob[0]), num_of(nb[0]) if nb else "?"))
        elif nb:
            m = PROSE_ONE.search(old); before = m.group(0) if m else "(unannotated GSI value)"
            repairs.append({"entity": "GSI", "repair_mode": "add_annotation_value_unit_conversion",
                "code": "MISSING-ANNOTATION+UNIT-MISMATCH", "before": before, "after": nb[0], "sentence": new})
            reason = ("Added the missing [GSI = ...] annotation and converted the in-prose value "
                      "(%s x 100 = %s); rewrote in plain reproductive-biology register." % (num_of(before), nb[0]))
        else:
            reason = "Trimmed an unsupported evaluative/interpretive GSI clause while keeping the record-grounded statement."
        if inserted:
            reason += " Inserted the record's co-located temperature annotation %s." % inserted
        edits.append({"sentence_before": old, "sentence_after": new, "inserted": inserted, "reason": reason})
    return cleanup(final), repairs, edits


def find_annot(spdir):
    for p in sorted(glob.glob(os.path.join(spdir, "*.json"))):
        b = os.path.basename(p)
        if re.match(r"^\d{4}_", b) and not b.endswith("_gsi_audit.json"):
            return p
    return None


def validate(final, repairs, edits):
    errs = []
    for r in ("grams per gram", "grammes per gram", "g/g", "g per gram", "g per g"):
        if r in final: errs.append("residue " + r)
    for span in GSI_BR.findall(final):
        if not span.rstrip("]").endswith("%"): errs.append("span not %%: " + span)
    for r in repairs:
        if r["after"] not in final or r["sentence"] not in final: errs.append("repair not substring")
    for e in edits:
        if e["sentence_after"] and e["sentence_after"] not in final: errs.append("edit not substring")
    DEB = ["reproduction buffer","energy allocation","somatic reserves","energy reserves","reproductive investment",
           "reproductive allocation","gonadal allocation","energetic trade","kappa","reserve","assimilation",
           "energy accumulation","channel","partition energetic","buffer against","allocation","energy budget",
           "energetic investment","energetic cost","energetic demands"]
    for s in re.split(r"(?<=[.])\s+", final):
        if "[GSI" in s:
            low = s.lower()
            for t in DEB:
                if t in low: errs.append("DEB %r in GSI sentence" % t)
    return errs


def main():
    dirs = sorted([d for d in glob.glob(os.path.join(ALLENT, "batch_*_manual_review", "still_needs_review", "*"))
                   if os.path.isdir(d)], key=os.path.basename)
    rep = nog = 0; problems = []
    for spdir in dirs:
        sp = os.path.basename(spdir)
        ap = find_annot(spdir)
        if not ap:
            problems.append((sp, "no annotated file")); continue
        rec = json.load(open(ap, encoding="utf-8"))
        txt = rec.get("result", rec.get("fixed_text", ""))
        out_path = ap[:-5] + "_gsi_audit.json"
        batch = os.path.basename(os.path.dirname(os.path.dirname(spdir))).split("_manual")[0]
        base = {"id": rec.get("id"), "specie": rec.get("specie"), "specie_en": rec.get("specie_en")}
        if gsi_record(spdir, sp) is None:
            out = dict(base, corrected_text=txt, verdict="NO_GSI", n_repairs=0,
                       repairs=[], prose_edits=[], corrected_text_final=txt)
            json.dump(out, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
            nog += 1; continue
        if sp not in OPS:
            problems.append((sp, "has GSI data but no ops")); continue
        try:
            final, repairs, edits = apply_ops(sp, txt)
        except Exception as e:
            problems.append((sp, "ERROR: %s" % e)); continue
        out = dict(base, corrected_text=cleanup(stage1(txt)), verdict="REPAIRED", n_repairs=len(repairs),
                   repairs=repairs, prose_edits=edits, corrected_text_final=final)
        errs = validate(final, repairs, edits)
        json.dump(out, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        rep += 1
        flag = (" !! " + "; ".join(errs)) if errs else ""
        print("OK   [%s] id=%-5s %-28s repairs=%d edits=%d%s" % (
            batch, rec["id"], sp, len(repairs), len(edits), flag))
    print("\nREPAIRED=%d  NO_GSI=%d  audit files=%d / %d" % (rep, nog, rep + nog, len(dirs)))
    if problems:
        print("PROBLEMS:")
        for sp, m in problems: print("  -", sp, "->", m)


if __name__ == "__main__":
    main()
