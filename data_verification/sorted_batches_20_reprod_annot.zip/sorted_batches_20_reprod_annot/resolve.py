#!/usr/bin/env python3
"""
Anchored re-span resolver (contiguous, right-aligned).

Convention (verified): the prose span an annotation refers to ends immediately
before the bracket. The correct verbatim value is therefore a CONTIGUOUS window
of prose ending at the bracket. We right-align the bracket's tokens onto the
prose tail, treating number-words<->digits and range forms as matchable, and
emit the verbatim prose slice.

Result kinds:
  ('respan',  verbatim_value)        clean verbatim span found (SPAN-C / qualifier)
  ('invented_tail', {...})           value has an appended unit phrase not in prose
                                     (e.g. '... eggs per clutch' but prose ends '... eggs')
  ('partial', {...})                 only part of value matched contiguously
  ('remove',  None)                  no quantitative span ends at the bracket
"""
import re

NUM_WORD = {
    'zero':'0','one':'1','single':'1','two':'2','three':'3','four':'4',
    'five':'5','six':'6','seven':'7','eight':'8','nine':'9','ten':'10','eleven':'11',
    'twelve':'12','dozen':'12','thirteen':'13','fourteen':'14','fifteen':'15',
    'sixteen':'16','seventeen':'17','eighteen':'18','nineteen':'19','twenty':'20',
    'thirty':'30','forty':'40','fifty':'50','sixty':'60','seventy':'70','eighty':'80',
    'ninety':'90','hundred':'100','thousand':'1000',
}
RANGE_SEP = {'to', '-', '–', '—', 'or'}
QUALIFIERS = ['approximately', 'about', 'roughly', 'around', 'up to',
              'nearly', 'almost', 'circa']
QUAL_WORDS = {'approximately','about','roughly','around','up','to','nearly','almost','circa'}

WORD_RE = re.compile(r"[A-Za-z]+|\d[\d,\.]*|[-–—]")


def toks_with_pos(s):
    return [(m.group(0), m.start(), m.end()) for m in WORD_RE.finditer(s)]


def canon(tok):
    t = tok.lower().replace(',', '')
    if t in NUM_WORD:
        return NUM_WORD[t]
    if t in RANGE_SEP:
        return '<r>'
    return t


def _is_num(c):
    return c.replace('.', '').isdigit()


def _rangeify(cs):
    """Treat 'and'/'or' as a range separator '<r>' when flanked by numbers,
    so 'between 2 and 4' matches '2-4'/'2 to 4'."""
    out = list(cs)
    for i in range(1, len(out) - 1):
        if out[i] in ('and', 'or') and _is_num(out[i-1]) and _is_num(out[i+1]):
            out[i] = '<r>'
    return out


def find_verbatim_span(prose_before, value):
    P = toks_with_pos(prose_before)
    V = toks_with_pos(value)
    if not P or not V:
        return ('remove', None)

    # strip a leading epistemic qualifier from the value; the prose's actual
    # preceding qualifier (if any) is re-added later, handling about<->approximately.
    if V:
        w0 = V[0][0].lower()
        if w0 in {'approximately','about','roughly','around','nearly','almost','circa'}:
            V = V[1:]
        elif w0 == 'up' and len(V) > 1 and V[1][0].lower() == 'to':
            V = V[2:]
    if not V:
        return ('remove', None)

    pc = _rangeify([canon(t) for t, _, _ in P])
    vc = _rangeify([canon(t) for t, _, _ in V])

    pi = len(P) - 1
    vi = len(V) - 1
    end_pi = pi

    # ---- Case: trim an appended unit phrase off the RIGHT of value ----
    # (prose tail noun != value tail token, e.g. value '... eggs per clutch',
    #  prose '... eggs'). Trim value-tail tokens until it lines up with prose tail.
    invented_tail = []
    if pc[pi] != vc[vi]:
        j = vi
        while j >= 0 and pc[pi] != vc[j]:
            invented_tail.insert(0, V[j][0])
            j -= 1
        if j < 0:
            return ('remove', None)   # value tail never appears at prose end
        vi = j

    # ---- shortest verbatim suffix containing value tokens as ordered subsequence ----
    # Walk both leftward; prose may have gap (filler) tokens which stay in the slice.
    n_value_tokens = vi + 1
    last_match_pi = end_pi
    unmatched_leading = []
    while vi >= 0 and pi >= 0:
        if pc[pi] == vc[vi]:
            last_match_pi = pi
            vi -= 1
        pi -= 1

    if vi >= 0:
        # could not place all value tokens as a subsequence
        unmatched_leading = [V[k][0] for k in range(vi + 1)
                             if V[k][0].lower() not in QUAL_WORDS and canon(V[k][0]) != '<r>']

    left_pi = _extend_left_qualifier(P, pc, last_match_pi)
    span = prose_before[P[left_pi][1]: P[end_pi][2]]
    span_len = end_pi - left_pi + 1

    invented_nonsep = [t for t in invented_tail if canon(t) != '<r>']

    # ---- guards: spurious far match (too much filler) or incomplete match ----
    over_long = span_len > n_value_tokens + 6

    if unmatched_leading or over_long:
        return ('partial', {'verbatim_span': span,
                            'leading_unmatched': unmatched_leading,
                            'invented': invented_nonsep,
                            'over_long': over_long})
    if invented_nonsep:
        # 312000-rule: if the invented part is a 'per <event>' phrase, try to
        # extend the verbatim span left to the event noun already in the prose.
        ext = _extend_to_event_noun(prose_before, P, pc, left_pi, end_pi, invented_nonsep)
        if ext is not None:
            return ('respan_event', {'span': ext, 'invented': invented_nonsep,
                                     'bare': span})
        return ('invented_tail', {'verbatim_span': span, 'invented': invented_nonsep})
    return ('respan', span)


TIME_WORDS = {'year','years','day','days','season','seasons','month','months',
              'week','weeks','annually','annum','daily','yearly'}
EVENT_STEMS = {'clutch':['clutch','clutches'], 'litter':['litter','litters'],
               'brood':['brood','broods'], 'nest':['nest','nests'],
               'spawning':['spawning','spawnings'], 'batch':['batch','batches'],
               'pregnancy':['pregnancy','pregnancies'], 'cocoon':['cocoon','cocoons'],
               'oviposition':['oviposition'], 'capsule':['capsule','capsules'],
               'birth':['birth','births'], 'event':['event','events']}
DETERMINERS = {'each','every','the','total','a','an'}


def _extend_to_event_noun(prose_before, P, pc, left_pi, end_pi, invented):
    """If `invented` is a 'per <event>' phrase, find the event noun verbatim to the
    left of the span (no time-unit word intervening) and return the extended
    verbatim slice; else None."""
    inv_low = [t.lower() for t in invented]
    if 'per' not in inv_low:
        return None
    # event noun candidates from the invented phrase
    targets = set()
    for t in inv_low:
        for stem, forms in EVENT_STEMS.items():
            if t in forms:
                targets.update(forms)
    if not targets:
        return None
    # scan leftward from just before the span
    for i in range(left_pi - 1, -1, -1):
        w = P[i][0].lower()
        if w in TIME_WORDS:
            return None                      # time unit intervenes -> abort
        if w in targets:
            start = i
            if i - 1 >= 0 and P[i-1][0].lower() in DETERMINERS:
                start = i - 1
            return prose_before[P[start][1]: P[end_pi][2]]
    return None


FILLER = {'of', 'a', 'an', 'the', 'each', 'typically', 'containing', 'contains',
          'contain', 'comprising', 'comprises', 'comprise', 'producing', 'produce',
          'produces', 'laying', 'lays', 'lay', 'averaging', 'averages', 'average',
          'with', 'and', 'consisting', 'consist', 'consists', 'total', 'about',
          'holding', 'holds', 'hold', 'carrying', 'carries', 'carry', 'yielding',
          'numbering', 'ranging', 'ranges', 'range', 'between', 'up'}


def _is_filler(tok):
    return tok.lower() in FILLER


def _extend_left_qualifier(P, pc, left_pi):
    """If the token just left of the span is an epistemic qualifier, include it.
    Handles single-word qualifiers and the two-word 'up to'."""
    if left_pi - 1 >= 0:
        w = P[left_pi - 1][0].lower()
        if w in {'approximately','about','roughly','around','nearly','almost','circa'}:
            return left_pi - 1
        if w == 'to' and left_pi - 2 >= 0 and P[left_pi - 2][0].lower() == 'up':
            return left_pi - 2
    return left_pi


def _maybe_remove(prose_before, value, P, pc, V, vc):
    """Value tail not at prose end. Check whether value's core number+noun exists
    anywhere contiguously in prose; if not -> remove."""
    return ('remove', None)
