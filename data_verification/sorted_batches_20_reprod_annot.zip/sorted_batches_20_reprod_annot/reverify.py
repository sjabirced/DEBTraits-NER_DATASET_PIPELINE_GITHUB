#!/usr/bin/env python3
"""
Mechanical re-verifier for Ri / N_R_i / F_R_i inline annotations.

Implements the NER Annotation Verifier prompt's rules DIRECTLY against the prose,
ignoring any previous verdicts. The verbatim substring check is the foundation
(the prompt's "mechanical, word-by-word" procedure). Deterministic cases are
resolved automatically; genuine re-span judgment cases are FLAGGED, never guessed.
"""
import json, re, os, sys

LABELS = ('N_R_i', 'F_R_i', 'Ri')   # order matters: match N_R_i before Ri
QUALIFIERS = ['approximately', 'about', 'roughly', 'around', 'up to',
              'nearly', 'almost', 'circa']
TIME_UNITS = ['per year', 'per day', 'per season', 'per month', 'per week',
              'annually', 'per annum', 'each year', 'each day', 'each season',
              'per breeding season', 'per spawning season', 'times per year']
EVENT_KEYWORDS = ['per clutch', 'per litter', 'per nest', 'per brood',
                  'per spawning event', 'per spawning', 'per batch',
                  'per oviposition', 'per capsule', 'per birth', 'per event',
                  'per nesting attempt', 'per nesting', 'per pregnancy',
                  'per cocoon', 'per reproductive event', 'per clutch per',
                  'every']
OFFSPRING_WORDS = ['eggs', 'egg', 'pups', 'pup', 'offspring', 'young', 'larvae',
                   'larva', 'chick', 'chicks', 'calf', 'calves', 'infant',
                   'infants', 'juvenile', 'juveniles', 'fry', 'oocytes',
                   'embryos', 'embryo', 'neonates', 'kits', 'hatchlings']
EVENT_WORDS = ['brood', 'broods', 'clutch', 'clutches', 'litter', 'litters',
               'nest', 'nests', 'spawning event', 'spawning events',
               'nesting attempt', 'pregnancy', 'pregnancies', 'cocoon', 'cocoons',
               'breeding event', 'breeding events', 'reproductive event',
               'reproductive events', 'spawning', 'spawn']

BRACKET_RE = re.compile(r'\[(N_R_i|F_R_i|Ri)\s*=\s*([^\]]*)\]')
ANY_BRACKET_RE = re.compile(r'\[[^\]]*\]')


def norm(s):
    """Collapse whitespace for robust substring comparison."""
    return re.sub(r'\s+', ' ', s).strip()


def clean_prose(sentence):
    """Remove all [..] annotation tags, leaving pure prose with tidy spaces."""
    return norm(ANY_BRACKET_RE.sub('', sentence))


def sentence_bounds(text, pos):
    """
    Return (start, end) of the sentence containing character index `pos`.
    Boundaries: '. ' where the period is NOT part of a decimal, or newline.
    """
    # search left
    start = 0
    for m in re.finditer(r'(?<!\d)\.\s|\n', text[:pos]):
        start = m.end()
    # search right
    end = len(text)
    m = re.search(r'(?<!\d)\.\s|\n', text[pos:])
    if m:
        end = pos + m.start() + 1   # include the period
    return start, end


def find_bracket_sentences(text):
    """Yield (label, value, bracket_str, sentence_str) for every Ri/N_R_i/F_R_i bracket."""
    for m in BRACKET_RE.finditer(text):
        label, value = m.group(1), m.group(2).strip()
        s, e = sentence_bounds(text, m.start())
        yield label, value, m.group(0), text[s:e]


def strip_leading_qualifier(value):
    """Return (qualifier_or_None, rest) splitting a leading epistemic qualifier."""
    low = value.lower()
    for q in sorted(QUALIFIERS, key=len, reverse=True):
        if low.startswith(q + ' '):
            return value[:len(q)], value[len(q)+1:]
    return None, value


def preceding_qualifier(prose, core):
    """If `core` occurs in prose and an epistemic qualifier sits immediately before it,
    return that qualifier (verbatim from prose); else None."""
    idx = prose.lower().find(core.lower())
    while idx != -1:
        before = prose[:idx].rstrip()
        for q in sorted(QUALIFIERS, key=len, reverse=True):
            if before.lower().endswith(q):
                # verbatim slice from prose
                return prose[len(before)-len(q):len(before)]
        idx = prose.lower().find(core.lower(), idx + 1)
    return None


def has_any(haystack, needles):
    low = haystack.lower()
    return any(re.search(r'\b' + re.escape(n) + r'\b', low) for n in needles)


def classify(label, value, prose):
    """
    Return dict: {code, action, correction, note}
      action in {'ok','relabel','add_qual','del_qual','respan','remove','flag'}
    Only deterministic, safe corrections are emitted; ambiguous ones -> 'flag'.
    """
    nvalue = norm(value)
    nprose = norm(prose)
    low_prose = nprose.lower()

    qual, rest = strip_leading_qualifier(nvalue)
    rest_n = norm(rest)

    value_verbatim = nvalue.lower() in low_prose
    rest_verbatim  = rest_n.lower() in low_prose

    # ---- SPAN family (run first; label logic applies after span is sound) ----
    span_code = None
    new_value = nvalue

    if value_verbatim:
        # value present as-is. But check SPAN-A: qualifier in prose right before it
        # that the bracket omitted.
        pq = preceding_qualifier(nprose, nvalue)
        if pq and not qual:
            span_code = 'SPAN-A'
            new_value = pq + ' ' + nvalue
    else:
        if qual and rest_verbatim:
            # bracket has a leading qualifier; value w/o it IS verbatim.
            pq = preceding_qualifier(nprose, rest_n)
            if pq is None:
                # qualifier not in prose -> SPAN-B (remove it)
                span_code = 'SPAN-B'
                new_value = rest_n
            elif pq.lower() != qual.lower():
                # different qualifier word in prose -> align
                span_code = 'SPAN-B'   # qualifier mismatch, treat as span fix
                new_value = pq + ' ' + rest_n
            else:
                # same qualifier but full string wasn't verbatim? whitespace edge; accept
                span_code = None
        else:
            # value (and its qualifier-stripped form) not verbatim -> SPAN-C or SPAN-D
            # Decide by whether the leading number/quantity token is present in prose.
            span_code = 'SPAN-CD'   # needs prose-level resolution -> flag/respan

    # ---- Label logic on the (possibly span-corrected) value ----
    eff = new_value if span_code in (None, 'SPAN-A', 'SPAN-B') else nvalue
    eff_low = eff.lower()

    label_code = None
    new_label = label
    has_time   = has_any(eff, TIME_UNITS)
    has_event_kw = has_any(eff, EVENT_KEYWORDS)
    has_offspring = has_any(eff, OFFSPRING_WORDS)
    has_event_word = has_any(eff, EVENT_WORDS)

    if label == 'N_R_i':
        if (has_time and not has_event_kw and
                not any(k in eff_low for k in ['per clutch','per litter','per nest','per brood',
                                               'per spawning','per batch','per birth','per event',
                                               'per pregnancy','per cocoon','per oviposition'])):
            # offspring-per-time mislabeled as per-event
            label_code = 'G1a'; new_label = 'Ri'
    elif label == 'Ri':
        if has_event_word and has_time and not has_offspring:
            label_code = 'G1c'; new_label = 'F_R_i'
    elif label == 'F_R_i':
        if has_offspring and has_time and not has_event_word:
            label_code = 'G1e'; new_label = 'Ri'

    # ---- assemble ----
    if span_code == 'SPAN-CD':
        return {'code': 'SPAN-C/D', 'action': 'flag',
                'correction': None,
                'note': 'value not verbatim and not a simple qualifier diff; '
                        'needs prose re-span (re-span vs true-remove)'}

    codes = [c for c in (label_code, span_code) if c]
    if not codes:
        return {'code': 'PASS', 'action': 'ok', 'correction': None, 'note': ''}

    corrected = f'[{new_label} = {new_value}]'
    action = 'relabel' if label_code and not span_code else \
             ('add_qual' if span_code == 'SPAN-A' else
              'del_qual' if span_code == 'SPAN-B' else 'fix')
    return {'code': '+'.join(codes), 'action': action,
            'correction': corrected, 'note': ''}


def main():
    base = sys.argv[1]
    input_dir = os.path.join(base, 'with_errors')
    files = sorted(f for f in os.listdir(input_dir) if f.endswith('.json'))

    from collections import Counter
    code_counts = Counter()
    flags = []
    per_file = []

    for fn in files:
        with open(os.path.join(input_dir, fn)) as f:
            item = json.load(f)
        text = item['corrected_text']
        recs = []
        for label, value, bracket, sentence in find_bracket_sentences(text):
            prose = clean_prose(sentence)
            res = classify(label, value, prose)
            code_counts[res['code']] += 1
            rec = {'bracket': bracket, 'sentence_prose': prose, **res}
            recs.append(rec)
            if res['action'] == 'flag':
                flags.append({'file': fn, 'species': item['specie'],
                              'bracket': bracket, 'prose': prose})
        per_file.append({'file': fn, 'species': item['specie'], 'records': recs})

    print('=== Verbatim re-verification landscape (batch) ===')
    for code, n in code_counts.most_common():
        print(f'  {code:12s}: {n}')
    print(f'\nTotal brackets: {sum(code_counts.values())}')
    print(f'FLAGGED for prose re-span judgment: {len(flags)}')

    with open(os.path.join(base, 'reverify_flags.json'), 'w') as f:
        json.dump(flags, f, indent=2, ensure_ascii=False)
    with open(os.path.join(base, 'reverify_perfile.json'), 'w') as f:
        json.dump(per_file, f, indent=2, ensure_ascii=False)
    print(f'\nWrote reverify_flags.json ({len(flags)} cases) and reverify_perfile.json')


if __name__ == '__main__':
    main()
