#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Batch repair of reproductive NER annotations (Ri, N_R_i, F_R_i) per
prompt_verification_reprod_fixed.md.

Core invariants enforced structurally:
  * NEVER delete a reproductive bracket (we only edit value/label, or expand).
  * Every new bracket value is, by construction, the verbatim text immediately
    preceding the bracket (a trailing slice of the prose), so it is always a
    verbatim substring of the (possibly prose-edited) sentence.
"""
import json, re, sys, os, collections, glob

HERE = os.path.dirname(os.path.abspath(__file__))

BR = re.compile(r'\[(Ri|N_R_i|F_R_i)\s*=\s*([^\]]*)\]')

QUAL = r'(?:approximately|about|roughly|around|up\s+to|nearly|almost|circa)'
NUMW = (r'(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|'
        r'thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|'
        r'twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|'
        r'thousand|single|once|twice)')
NUMD = r'\d[\d,]*(?:\.\d+)?'
NUM = r'(?:%s|%s)' % (NUMD, NUMW)
RANGE = r'%s\s*(?:to|and|or|through|[-–—])\s*%s' % (NUM, NUM)
# a spelled-out compound number kept as ONE unit, e.g. 'two thousand',
# 'two hundred and nineteen', 'one hundred thousand'
COMPOUND = (r'(?:%s)(?:[\s-]+(?:hundred|thousand|million|billion))+'
            r'(?:\s+(?:and\s+)?(?:%s)(?:[\s-]+(?:hundred|thousand))?)?'
            % (NUM, NUM))
# a range of scaled numbers, e.g. '2.5 million to 3.3 million'
SCALERANGE = (r'(?:%s)\s+(?:hundred|thousand|million|billion)\s*'
              r'(?:to|and|or|through|[-–—])\s*(?:%s)\s+'
              r'(?:hundred|thousand|million|billion)' % (NUM, NUM))
# qualitative quantifiers
QUALI = (r'(?:multiple|several|numerous|many|few|dozens?|scores|hundreds|'
         r'thousands|(?:a\s+)?(?:large|small|considerable|substantial|modest|'
         r'great|huge|enormous|vast)\s+numbers?\s+of)')
# quantity phrase: optional qualifier, optional 'between', then compound/range/etc
QUANT = re.compile(
    r'(?:%s\s+)?(?:between\s+)?(?:%s|%s|%s|%s|%s)'
    % (QUAL, SCALERANGE, COMPOUND, RANGE, NUM, QUALI), re.IGNORECASE)
# a frequency phrase with no event noun, e.g. 'approximately once every three
# years', 'every 0.75 years' -- a valid F_R_i frequency to anchor on
FREQ_PHRASE = re.compile(
    r'(?:%s\s+)?(?:once|twice|a\s+single|single|[\d.]+)?\s*every\s+'
    r'(?:[\d.]+|\w+)(?:\s+to\s+(?:[\d.]+|\w+))?\s+'
    r'(?:years?|days?|months?|weeks?)' % QUAL, re.IGNORECASE)
# a bare duration phrase, e.g. 'thirty days', 'roughly 2.7 years', '120 days'
DURATION = re.compile(
    r'^(?:%s\s+)?(?:%s|%s)[-\s]+'
    r'(?:days?|years?|months?|weeks?|hours?|nights?)\b'
    % (QUAL, RANGE, NUM), re.IGNORECASE)

TIME = re.compile(r'(per\s+year|per\s+day|per\s+season|per\s+month|per\s+week|'
                  r'per\s+annum|per\s+breeding\s+season|annually|annual|'
                  r'each\s+year|each\s+day|each\s+season|each\s+month|'
                  r'every\s+year|per\s+reproductive\s+year|reproductive\s+year|'
                  r'over\s+a\s+[\d.]+[-\s]day\s+period|[\d.]+[-\s]day\s+period|'
                  r'over\s+the\s+\w+\s+season|within\s+a\s+single\s+(?:\w+\s+)?season|'
                  r'during\s+a\s+single\s+(?:\w+\s+)?season|in\s+a\s+given\s+year|'
                  r'over\s+the\s+course\s+of\s+(?:a|an)\s+(?:entire\s+|single\s+)?(?:[\d.]+[-\s]day\s+)?year|'
                  r'over\s+the\s+course\s+of\s+a\s+(?:single\s+)?day|'
                  r'per\s+decade|per\s+[\d.]+\s+months?|'
                  r'over\s+the\s+entire\s+span\s+of\s+a\s+single\s+year|'
                  r'over\s+the\s+span\s+of\s+a\s+(?:single\s+)?year|'
                  r'yearly|daily|per\s+individual\s+per\s+year|'
                  r'per\s+[\d.]+\s+days?|per\s+[\d.]+\s+years?|'
                  r'per\s+[\d.]+[-\s]day\s+year|'
                  r'each\s+week|per\s+[\d.]+\s+to\s+[\d.]+\s+(?:days?|years?|months?|weeks?)|'
                  r'every\s+(?:[\d.]+|\w+)\s+hours?|per\s+[\d.]+\s+hours?|'
                  r'per\s+[\d.]+[-\s]day\s+interval|[\d.]+[-\s]day\s+interval|'
                  r'over\s+(?:a|an)\s+interval\s+of\s+[\d.]+\s+days?|'
                  r'interval\s+of\s+[\d.]+\s+days?|'
                  r'over\s+(?:a|an)\s+[\d.]+[-\s]day\s+(?:\w+\s+)?window|'
                  r'in\s+a\s+single\s+day|across\s+the\s+season|'
                  r'within\s+a\s+single\s+year|in\s+a\s+single\s+year|'
                  r'within\s+a\s+year|over\s+the\s+year|per\s+annum|'
                  r'over\s+a\s+period\s+of\s+[\d.]+\s+(?:days?|years?|months?|weeks?)|'
                  r'over\s+[\d.]+\s+(?:days?|years?|months?|weeks?)|'
                  r'in\s+[\d.]+\s+(?:days?|years?|months?|weeks?)|'
                  r'over\s+(?:a|its|her|their)\s+(?:reproductive\s+)?lifespan|'
                  r'over\s+the\s+course\s+of\s+(?:its|their)\s+li(?:fe|ves)|'
                  r'over\s+(?:its|their)\s+li(?:fe|ves|fetime)|'
                  r'(?:reproductive\s+)?lifespan|'
                  r'every\s+(?:[\d.]+|\w+)\s+to\s+(?:[\d.]+|\w+)\s+(?:years?|days?|months?|weeks?)|'
                  r'each\s+(?:[\d.]+|\w+)\s+(?:or|to)\s+(?:[\d.]+|\w+)\s+(?:years?|days?|months?|weeks?)|'
                  r'every\s+day|every\s+(?:[\d.]+|\w+)\s+(?:days?|years?|months?|weeks?)|'
                  r'breeding\s+season|spawning\s+season|nesting\s+season|'
                  r'reproductive\s+season|each\s+spring|each\s+summer|'
                  r'per\s+season|each\s+season|within\s+a\s+single\s+season|'
                  r'in\s+a\s+single\s+season|over\s+the\s+season|'
                  r'per\s+active\s+season|in\s+a\s+single\s+active\s+season|'
                  r'single\s+active\s+season|active\s+season|'
                  r'over\s+a\s+full\s+year|a\s+full\s+year|full\s+year|'
                  r'over\s+a\s+year|over\s+a\s+single\s+year|'
                  r'over\s+the\s+course\s+of\s+the\s+season|'
                  r'over\s+the\s+course\s+of\s+the\s+year|'
                  r'throughout\s+the\s+season|throughout\s+the\s+year|'
                  r'over\s+the\s+course\s+of\s+(?:her|his|its|their)\s+lifetime|'
                  r'per\s+lifetime|over\s+(?:her|his|its|the|their)\s+lifetime|'
                  r'lifetime)',
                  re.IGNORECASE)
EVENT = re.compile(r'(clutch|clutches|litter|litters|brood|broods|nest|nests|'
                   r'spawning|spawn|reproductive\s+event|breeding\s+event|'
                   r'nesting\s+attempt|breeding\s+attempt|nesting|oviposition|'
                   r'pregnanc|cocoon|batch|birth|births|parturition|calving|'
                   r'gestation\s+event|reproductive\s+cycle|breeding\s+cycle|'
                   r'reproductive\s+events?|breeding\s+events?|events?|'
                   r'strobilation\s+event|strobilation|nesting\s+attempts?|'
                   r'attempts?|times|brooding\s+cycles?|brood\s+cycles?)',
                   re.IGNORECASE)
OFFSPRING = re.compile(r'(egg|eggs|pup|pups|offspring|young|larva|larvae|'
                       r'juvenile|fry|infant|hatchling|neonate|embryo|'
                       r'fingerling|ova|oocyte|ovum|calf|calves|kid|kids|'
                       r'cub|cubs|fawn|fawns|joey|kit|kits|lamb|lambs|'
                       r'piglet|foal|foals|chick|chicks|nestling|nestlings|'
                       r'fledgling|kitten|whelp|glochidia|glochidium|'
                       r'spat|nauplii|medusae|medusa|fawns?|kid|kids)',
                       re.IGNORECASE)
EVENT_OR_OFF = re.compile(EVENT.pattern + '|' + OFFSPRING.pattern, re.IGNORECASE)
# per-event anchor: explicit 'per X' keyword OR container construction
PEREVENT = re.compile(r'(per\s+clutch|per\s+litter|per\s+brood|per\s+nest|'
                      r'per\s+spawning|per\s+batch|per\s+oviposition|'
                      r'per\s+capsule|per\s+birth|per\s+event|'
                      r'per\s+reproductive\s+event|per\s+nesting|'
                      r'per\s+pregnancy|per\s+cocoon|per\s+parturition|'
                      r'per[-\s]spawn\b|per\s+calving|\beach\b|\bevery\b|'
                      r'per\s+reproductive\s+cycle|reproductive\s+cycle|'
                      r'per\s+breeding\s+cycle|breeding\s+cycle|'
                      r'per\s+gestation(?:\s+event)?|gestation\s+event|'
                      r'consisting\s+of|containing|contains|contain|comprises|'
                      r'parturition|calving|spawning\s+event|nesting\s+attempt|'
                      r'per\s+strobilation\s+event|strobilation\s+event|'
                      r'per\s+host\s+nest|host\s+nest|'
                      r'per\s+parasitism\s+event|parasitism\s+event|'
                      r'per\s+breeding\s+event|breeding\s+event|'
                      r'per\s+moult\s+interval|moult\s+interval|'
                      r'night\s+of\s+copulation|per\s+copulation|copulation|'
                      r'per\s+mating\s+event|mating\s+event|'
                      r'per\s+spawning\s+episode|spawning\s+episode|'
                      r'per\s+bag|per\s+egg\s+bag|egg\s+bag|\bbag\b|'
                      r'per\s+breeding\s+attempt|breeding\s+attempt|'
                      r'clutch\s+of|litter\s+of|brood\s+of|clutches\s+of|'
                      r'litters\s+of|broods\s+of|'
                      r'clutch|clutches|litter|litters|brood|broods|'
                      r'nest|nests|batch|batches|capsule|capsules|cocoon|'
                      r'cocoons|egg\s+mass|egg\s+case|'
                      r'(?:clutch|litter|brood|nest)\s+sizes?\s+of)',
                      re.IGNORECASE)
DET = {'a', 'an', 'the', 'each', 'every', 'single', 'one'}


_SENT_BOUND = re.compile(r'[.!?]\s+(?=[A-Z])')


def clause_pre(text, br_start):
    """Prose a bracket annotates: text between this bracket and the nearest
    preceding boundary — a previous bracket ']', a newline, or a sentence end.
    Never crosses a bracket or a sentence boundary (decimals like '3.2' and
    genus abbreviations like 'A. hians' are not treated as boundaries)."""
    seg = text[:br_start]
    cut = max(seg.rfind('\n'), seg.rfind(']'))
    sb = None
    for m in _SENT_BOUND.finditer(seg):
        if m.start() == 0 or not seg[m.start() - 1].isdigit():
            sb = m
    if sb and sb.end() > cut:
        cut = sb.end() - 1
    return seg[cut + 1:] if cut >= 0 else seg


def num_token(s):
    m = re.search(r'\d[\d,]*(?:\.\d+)?', s or '')
    return m.group().replace(',', '') if m else None


_WORDVAL = {'single': 1, 'one': 1, 'once': 1, 'two': 2, 'twice': 2, 'three': 3,
            'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9,
            'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13,
            'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17,
            'eighteen': 18, 'nineteen': 19, 'twenty': 20, 'thirty': 30,
            'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70, 'eighty': 80,
            'ninety': 90, 'hundred': 100, 'thousand': 1000}
_NUMTOKEN = re.compile(
    r'(\d[\d,]*(?:\.\d+)?|\b(?:' + '|'.join(_WORDVAL) + r')\b)'
    r'(\s+(?:million|billion|thousand))?', re.IGNORECASE)
_MULT = {'thousand': 1e3, 'million': 1e6, 'billion': 1e9}


def _tok_value(m):
    base = m.group(1)
    v = float(_WORDVAL[base.lower()]) if base.lower() in _WORDVAL \
        else float(base.replace(',', ''))
    if m.group(2):
        v *= _MULT[m.group(2).strip().lower()]
    return v


def num_value(s):
    """Numeric value of the FIRST number in s (digit or number-word). Excludes
    the bare article 'a'/'an' to avoid mis-reading 'a litter of eight'. None if
    no number is present."""
    m = _NUMTOKEN.search(s or '')
    return _tok_value(m) if m else None


_SCALE = {'hundred': 100, 'thousand': 1000, 'million': 1e6, 'billion': 1e9}


def _compound_values(s):
    """Spelled-out compound numbers, e.g. 'two hundred and nineteen' -> 219,
    'one hundred thousand' -> 100000. Best-effort and ADDITIVE: it may emit a
    few spurious sums (e.g. for 'two and three'), which only makes the numeric
    guard more lenient, never stricter."""
    words = re.findall(r"[a-z]+|\d[\d,]*(?:\.\d+)?", (s or '').lower())
    vals, cur, run, active = set(), 0, 0, False
    for w in words:
        if w in _WORDVAL and w not in _SCALE:
            run += _WORDVAL[w]
            active = True
        elif w == 'hundred':
            run = (run or 1) * 100
            active = True
        elif w in ('thousand', 'million', 'billion'):
            cur += (run or 1) * _SCALE[w]
            run = 0
            active = True
        elif w == 'half' and active:
            run += 0.5
        elif w == 'quarter' and active:
            run += 0.25
        elif w in ('and', 'a', 'an') and active:
            continue
        else:
            if active:
                vals.add(float(cur + run))
            cur = run = 0
            active = False
    if active:
        vals.add(float(cur + run))
    return vals


def num_values_all(s):
    """All numeric values appearing in s (digits, number-words, compounds)."""
    return {_tok_value(m) for m in _NUMTOKEN.finditer(s or '')} \
        | _compound_values(s)


def want_num(value):
    """The original bracket's COUNT digit, taken from the numerator only (before
    a per/every/over/within denominator) so an interval number like the '2' in
    'once every 2 years' is not mistaken for the count."""
    head = re.split(r'(?:^|\s+)(?:per|every|over|within|in|each)\b',
                    value or '', 1)[0]
    return num_token(head)


def build_value(pre, orig_value=None, orig_label=None):
    """Return (start_index_in_pre, base_value_string) anchored on the quantity
    the bracket counts, running to the end of pre.

    Priority for the anchor:
      1. the quantity whose digits match the original bracket value (`want`);
      2. the last quantity followed by a noun of the type the original label
         implies (F_R_i -> event, N_R_i/Ri -> offspring), so 'single clutch ...
         two eggs' anchors on the clutch for an F_R_i bracket;
      3. the last quantity followed by any offspring/event noun;
      4. (no quantity tied to a noun) the last event/offspring noun itself;
      5. a quantity-less 'every N years' frequency phrase;
      6. the last quantity overall.
    Returns None if nothing usable exists."""
    pre_r = pre.rstrip()
    want = want_num(orig_value)
    want_m = followed_m = followed_off = followed_event = overall = None
    for m in QUANT.finditer(pre_r):
        overall = m
        if want and num_token(m.group()) == want:
            # don't match an interval/denominator number ('every 1 to 3 years')
            prevw = (pre_r[:m.start()].split() or [''])[-1].lower()
            tailw = (pre_r[m.end():].split() or [''])[0].lower().rstrip('.,;')
            if prevw not in ('every', 'per', 'each', 'over', 'within', 'in') \
               and tailw not in ('day', 'days', 'year', 'years', 'month',
                                 'months', 'week', 'weeks'):
                want_m = m
        tail = pre_r[m.end():]
        nxt = ' '.join(tail.split()[:5])
        om, em_ = OFFSPRING.search(nxt), EVENT.search(nxt)
        elided = re.match(r'\s*per\s+(?:clutch|litter|brood|nest|spawning|'
                          r'capsule|cocoon|batch)', tail, re.IGNORECASE)
        # which noun comes first after the quantity decides what it counts
        if elided or (om and (not em_ or om.start() < em_.start())):
            followed_off = m
            followed_m = m
        elif em_:
            followed_event = m
            followed_m = m
    pref = followed_event if orig_label == 'F_R_i' else followed_off
    chosen = want_m or pref or followed_m
    if chosen:
        return chosen.start(), pre_r[chosen.start():]
    em = None
    for mm in EVENT_OR_OFF.finditer(pre_r):
        em = mm
    if em:
        return em.start(), pre_r[em.start():]
    fm = None                       # a quantity-less 'every N years' frequency
    for mm in FREQ_PHRASE.finditer(pre_r):
        fm = mm
    if fm:
        return fm.start(), pre_r[fm.start():]
    if overall:
        return overall.start(), pre_r[overall.start():]
    return None


def extend_left_to_container(pre, qstart):
    """For an N_R_i bare count: find the per-event/container phrase nearest to
    the left of the quantity (within ~80 chars) and return the index where that
    phrase begins, so the bracket can be expanded to the verbatim container."""
    head = pre[:qstart]
    lo = max(0, len(head) - 80)
    comma = head.rfind(',')           # don't cross a clause boundary
    if comma >= lo:
        lo = comma + 1
    earliest = None
    for mm in PEREVENT.finditer(head):
        if mm.start() >= lo:
            if earliest is None or mm.start() < earliest.start():
                earliest = mm
    if not earliest:
        return None
    start = earliest.start()
    # swallow an immediately-preceding determiner / distributive word
    dm = re.search(r'(\b\w+)\s*$', head[:start])
    if dm and dm.group(1).lower() in DET:
        start = dm.start(1)
    return start


def extend_left_to_time(pre, qstart):
    """For an F_R_i with no captured time word: find the time expression nearest
    to the left of the quantity (within ~80 chars); return its start or None."""
    head = pre[:qstart]
    lo = max(0, len(head) - 80)
    last = None
    for mm in TIME.finditer(head):
        if mm.start() >= lo:
            last = mm
    return last.start() if last else None


_CONTAINER_OF = re.compile(
    r'(clutch|clutches|litter|litters|brood|broods|nest|nests|batch|batches|'
    r'capsule|capsules|cocoon|cocoons|spawning\s+event|egg\s+mass)'
    r'(?:\s+sizes?)?\s+'
    r'(of|containing|comprising|holding|with)\s*$', re.IGNORECASE)


def _first_noun(region):
    o = OFFSPRING.search(region)
    e = EVENT.search(region)
    if o and (not e or o.start() < e.start()):
        return 'off'
    if e:
        return 'event'
    return None


def quantified_noun(val):
    """What does the quantity count? Returns 'off' (offspring count),
    'event' (reproductive-event count), or None.

    A value string starts with its own quantity, so classify by the head noun
    following the FIRST quantity. Special case: a container construction
    ('clutches of N', 'litter of N') means N counts OFFSPRING, even though the
    event noun sits just before the number."""
    q = QUANT.search(val)
    if not q:
        return _first_noun(val)
    after = val[q.end():]
    # 'N per clutch/litter/...' with the offspring noun elided -> offspring count
    if re.match(r'\s*per\s+(?:clutch|litter|brood|nest|spawning|capsule|'
                r'cocoon|batch|reproductive\s+event)', after, re.IGNORECASE):
        return 'off'
    head_region = ' '.join(after.split()[:5])
    k = _first_noun(head_region)
    if k:
        return k
    # nothing right after the quantity: is it 'EVENT of NUMBER' (container)?
    if _CONTAINER_OF.search(val[:q.start()]):
        return 'off'
    return _first_noun(val)


def desired_label(val):
    t = bool(TIME.search(val))
    kind = quantified_noun(val)
    if kind == 'off':
        if t:
            return 'Ri'             # offspring per time -> rate
        if PEREVENT.search(val):
            return 'N_R_i'          # offspring per event -> fecundity
        return None
    if kind == 'event':
        return 'F_R_i'             # event count -> frequency
    return None


def has_perevent(val):
    return bool(PEREVENT.search(val))


# an explicit 'per <event>' denominator (not a bare container noun) -- used to
# detect tautological frequencies like '1 clutch per spawning event'
PER_EVENT_DENOM = re.compile(
    r'per\s+(?:clutch|litter|brood|nest|spawning|batch|capsule|cocoon|'
    r'oviposition|nesting|pregnancy|parturition|gestation|reproductive\s+event|'
    r'spawning\s+event|strobilation\s+event|host\s+nest|reproductive\s+cycle|'
    r'breeding\s+cycle|instar|breeding\s+attempt|'
    r'breeding\s+event)', re.IGNORECASE)

# morphological denominators -> not a valid N_R_i/Ri (G1a-morpho); flag, keep
MORPHO = re.compile(r'per\s+(?:kilo)?gram|per\s+kg\b|per\s+g\b|'
                    r'per\s+kilogram|per\s+body\s+mass|\bper\s+mm\b|\bper\s+cm\b',
                    re.IGNORECASE)


def epistemic_before(pre, vstart):
    """If an epistemic qualifier sits immediately before vstart, return it."""
    head = pre[:vstart].rstrip()
    m = re.search(QUAL + r'\s*$', head, re.IGNORECASE)
    return m.group() if m else None


def value_found_repair(label, value, pre):
    """If the original value is already a verbatim substring of the clause
    (the bracket need not be adjacent to it), handle the minimal cases here:
    return None if fully compliant, a SPAN-A dict if only a leading epistemic
    qualifier is missing, or False to signal 'fall through to a full rebuild'."""
    pos = pre.rfind(value)
    if pos == -1 or not value:
        return False
    complete = ((label in ('F_R_i', 'Ri') and TIME.search(value)) or
                (label == 'N_R_i' and has_perevent(value)))
    if desired_label(value) != label or not complete:
        return False  # needs relabel or definition repair -> rebuild
    qm = re.search('(' + QUAL + r')\s*$', pre[:pos], re.IGNORECASE)
    if qm and re.match(QUAL, value, re.IGNORECASE) is None:
        nv = pre[qm.start():pos + len(value)]
        return {'new_label': label, 'new_value': nv,
                'repair_mode': 'FIX_SPAN', 'code': 'SPAN-A',
                'prose_insert': None}
    return None  # compliant -> leave untouched


def repair_bracket(label, value, pre):
    """Return dict(new_label, new_value, repair_mode, code, prose_insert) or
    None if already compliant. prose_insert: text to append to prose (MODE 2)."""
    def flag():
        return {'new_label': label, 'new_value': value,
                'repair_mode': 'FLAG_MANUAL', 'code': 'FLAG-MANUAL',
                'prose_insert': None}

    # G1a-morpho: a per-mass/per-length count is not a valid N_R_i/Ri -> keep
    # the bracket and flag for a human (never fabricate a per-event keyword).
    if MORPHO.search(value):
        return flag()

    vf = value_found_repair(label, value, pre)
    if vf is not False:
        return vf  # None (compliant) or a clean SPAN-A fix

    def clean_for_mode2(b):
        # only edit prose for a short, clean count/frequency phrase; reject
        # interval-like or already-time-bearing spans (avoids garbled output)
        if len(b.split()) > 8:
            return False
        return not re.search(r'\b(days?|year|years|month|months|week|weeks|'
                             r'interval|average|averages|averaging)\b', b, re.I)

    bv = build_value(pre, value, label)
    if bv is None:
        return flag()
    qstart, base = bv

    # decide preliminary nature from the head noun the quantity counts
    t = bool(TIME.search(base))
    kind = quantified_noun(base)
    pe = has_perevent(base)

    prose_insert = None
    final_start = qstart
    final_val = base
    extended = False
    PUP = r'pup|infant|cub|calf|kid|joey|kitten|whelp|piglet|lamb|fawn|foal'
    # MODE 2 (prose edit) is only legitimate for an explicit count/frequency;
    # if the anchored span carries no number, the value is a number-less back-
    # reference and must be flagged, not fabricated into a per-year frequency.
    has_num = num_value(base) is not None

    if kind == 'off' and not t:
        # offspring count. Prefer a per-event container (N_R_i); else a
        # preceding time word makes it offspring-per-time (Ri); else MODE 2.
        if not pe:
            nc = extend_left_to_container(pre, qstart)
            nt = extend_left_to_time(pre, qstart)
            if nc is not None:
                final_start, extended = nc, True
                final_val = pre.rstrip()[nc:]
            elif nt is not None and nt < qstart:
                final_start, extended = nt, True
                final_val = pre.rstrip()[nt:]
            elif has_num and clean_for_mode2(base):
                # choose the per-event keyword from the event noun the sentence
                # actually uses (capsule/brood/nest/spawning/...), not a default
                kw = 'per clutch'
                if re.search(r'capsule', pre, re.I):
                    kw = 'per capsule'
                elif re.search(r'cocoon', pre, re.I):
                    kw = 'per cocoon'
                elif re.search(r'spawn', pre, re.I):
                    kw = 'per spawning event'
                elif re.search(r'\bnest', pre, re.I):
                    kw = 'per nest'
                elif re.search(r'brood', pre, re.I):
                    kw = 'per brood'
                elif re.search(PUP, base, re.I) or re.search(r'litter', pre, re.I):
                    kw = 'per litter'
                prose_insert = kw
                final_val = base + ' ' + kw
            else:
                return flag()
    elif kind == 'event' and not t:
        # event frequency missing time
        nt = extend_left_to_time(pre, qstart)
        if nt is not None and nt < qstart:
            final_start, extended = nt, True
            final_val = pre.rstrip()[nt:]
        elif has_num and clean_for_mode2(base) \
                and not PER_EVENT_DENOM.search(base):
            # don't add a time unit to an already per-event span ('1 clutch per
            # spawning event') -- that is tautological; flag it instead
            prose_insert = 'per year'
            final_val = base + ' per year'
        else:
            return flag()
    # else: has time -> base already carries it (Ri or F_R_i), keep base

    # Label from the COUNTED quantity's kind (fixed before any left-expansion),
    # not from the final string (whose leading token may now be a container).
    def label_from(k, val):
        if k == 'off':
            return 'Ri' if TIME.search(val) else (
                'N_R_i' if has_perevent(val) else None)
        if k == 'event':
            return 'F_R_i'
        return None

    new_label = label_from(kind, final_val) or label
    relabeled = new_label != label

    # Safety nets against anchoring on the wrong span (typically a value not
    # adjacent to its bracket) -> never corrupt, flag for human review instead:
    #  (a) the rebuilt span is a bare duration with no offspring/event referent
    #      ('thirty days', '2.7 years') -- a stray interval, not a reproductive
    #      value;
    #  (b) the original's number appears nowhere in the rebuilt span AND either
    #      the entity changed or the number was a real count (>=2). A missing
    #      '1' alone is fine ('1 clutch' -> 'a clutch every 10 days').
    if DURATION.match(final_val) and quantified_noun(final_val) is None:
        return flag()
    ov = num_value(value)
    fn_nums = num_values_all(final_val)
    mismatch = ov is not None and fn_nums and ov not in fn_nums
    if mismatch and (relabeled or ov != 1):
        return flag()

    # no-op guard: nothing actually changed -> leave bracket untouched
    if final_val == value and not relabeled and prose_insert is None:
        return None

    def relabel_code(old, new):
        if old == 'N_R_i' and new == 'Ri':
            return 'G1a'
        if old == 'Ri' and new == 'F_R_i':
            return 'G1c'
        if old == 'F_R_i' and new == 'Ri':
            return 'G1e'
        return 'RELABEL'

    q_added = (re.match(QUAL, final_val, re.I) is not None
               and re.match(QUAL, value, re.I) is None)
    q_removed = (re.match(QUAL, value, re.I) is not None
                 and re.match(QUAL, final_val, re.I) is None)

    # classify repair (label fix has priority for the code per prompt order)
    if prose_insert is not None:
        mode = 'EDIT_PROSE'
        code = 'N_R_i-BARE' if new_label == 'N_R_i' else 'F_R_i-NOTIME'
    elif relabeled and final_val == value:
        mode = 'RELABEL'
        code = relabel_code(label, new_label)
    elif extended:
        mode = 'EXPAND_BRACKET'
        code = 'N_R_i-BARE' if new_label == 'N_R_i' else 'F_R_i-NOTIME'
    else:
        mode = 'FIX_SPAN'
        code = 'SPAN-A' if q_added else 'SPAN-B' if q_removed else 'SPAN-C'

    if relabeled and mode in ('FIX_SPAN', 'EXPAND_BRACKET'):
        code = relabel_code(label, new_label)
    return {'new_label': new_label, 'new_value': final_val,
            'repair_mode': mode, 'code': code, 'prose_insert': prose_insert}


def process_text(corrected_text):
    """Return (final_text, repairs, prose_edits)."""
    repairs = []
    prose_edits = []
    # collect matches first (positions in original); apply right-to-left
    matches = list(BR.finditer(corrected_text))
    out = corrected_text
    # process right to left so indices stay valid
    for m in reversed(matches):
        label, value = m.group(1), m.group(2).strip()
        pre = clause_pre(corrected_text, m.start())

        # G1d: two labels packed in one bracket -> split, never collapse
        if re.search(r'[;,]\s*(?:Ri|N_R_i|F_R_i)\s*=', value):
            pieces = re.split(r'\s*[;,]\s*(?=(?:Ri|N_R_i|F_R_i)\s*=)', value)
            subs = [(label, pieces[0].strip())]
            for p in pieces[1:]:
                mm = re.match(r'(Ri|N_R_i|F_R_i)\s*=\s*(.*)', p)
                if mm:
                    subs.append((mm.group(1), mm.group(2).strip()))
            # Split into separate brackets (never collapse two labels into one).
            # The shared prose is conflated, so keep each authored sub-value and
            # FLAG for human review rather than risk mislabeling/duplicating.
            combined = ' '.join('[%s = %s]' % (sl, sv) for sl, sv in subs)
            out = out[:m.start()] + combined + out[m.end():]
            repairs.append({
                'entity': '+'.join(s[0] for s in subs),
                'repair_mode': 'FLAG_MANUAL', 'code': 'G1d',
                'before': m.group(0), 'after': combined,
                'sentence': (pre.strip()[-300:] +
                             corrected_text[m.start():m.end()]).strip()})
            continue

        rep = repair_bracket(label, value, pre)
        if rep is None:
            continue
        sentence = pre.strip()[-300:] + corrected_text[m.start():m.end()]
        new_bracket = '[%s = %s]' % (rep['new_label'], rep['new_value'])
        if rep['repair_mode'] == 'EDIT_PROSE' and rep['prose_insert']:
            # insert keyword into prose between value-end and bracket
            ins = ' ' + rep['prose_insert']
            sb = corrected_text[:m.start()].rstrip()
            sentence_before = sb[-200:] + ' ' + corrected_text[m.start():m.end()]
            out = (out[:m.start()].rstrip() + ins + ' ' +
                   new_bracket + out[m.end():])
            sentence_after = sb[-200:] + ins + ' ' + new_bracket
            prose_edits.append({
                'sentence_before': sentence_before,
                'sentence_after': sentence_after,
                'inserted': rep['prose_insert'],
                'reason': ("Count/frequency stated with no per-event/time word "
                           "anywhere in the sentence; inserted minimal keyword "
                           "to satisfy the entity definition. No number or fact "
                           "changed.")})
        else:
            out = out[:m.start()] + new_bracket + out[m.end():]
        repairs.append({
            'entity': rep['new_label'],
            'repair_mode': rep['repair_mode'],
            'code': rep['code'],
            'before': '[%s = %s]' % (label, value),
            'after': new_bracket,
            'sentence': sentence.strip()})
    repairs.reverse()
    prose_edits.reverse()
    return out, repairs, prose_edits


def main(preview_n=None, write=False, root=HERE):
    with_errors = os.path.join(root, 'with_errors')
    files = sorted(glob.glob(os.path.join(with_errors, '*.json')))
    if preview_n:
        files = files[:preview_n]

    summary = {
        'n_files': 0, 'n_files_repaired': 0, 'n_repairs_total': 0,
        'n_prose_edits_total': 0, 'repairs_by_code': collections.Counter(),
        'files_flagged_manual': [],
        'integrity_check': {'files_with_bracket_count_drop': [],
                            'files_with_nonverbatim_bracket': []}}

    for fp in files:
        with open(fp, encoding='utf-8') as fh:
            data = json.load(fh)
        ct = data.get('corrected_text', '') or ''
        final, repairs, prose_edits = process_text(ct)

        # integrity: bracket count
        n_in = len(BR.findall(ct))
        n_out = len(BR.findall(final))
        sp = os.path.basename(fp)
        if n_out < n_in:
            summary['integrity_check']['files_with_bracket_count_drop'].append(sp)
        # integrity: every bracket value verbatim before its bracket
        # (intentionally-flagged FLAG_MANUAL brackets are excluded)
        flagged = set()
        for r in repairs:
            if r['repair_mode'] == 'FLAG_MANUAL':
                flagged.update(re.findall(
                    r'\[(?:Ri|N_R_i|F_R_i)\s*=\s*[^\]]*\]', r['after']))
        nonverb = False
        for m in BR.finditer(final):
            if m.group(0) in flagged:
                continue
            val = m.group(2).strip()
            pre = clause_pre(final, m.start())
            # value must be a verbatim substring of its sentence (the bracket
            # need not sit immediately after it)
            if val not in pre:
                nonverb = True
                break
        if nonverb:
            summary['integrity_check']['files_with_nonverbatim_bracket'].append(sp)

        verdict = 'FAIL' if repairs or prose_edits else 'PASS'
        data['verdict'] = verdict
        data['n_repairs'] = len(repairs)
        data['repairs'] = repairs
        data['prose_edits'] = prose_edits
        data['corrected_text_final'] = final if verdict == 'FAIL' else ct

        for r in repairs:
            summary['repairs_by_code'][r['code']] += 1
            if r['repair_mode'] == 'FLAG_MANUAL':
                if data['specie'] not in summary['files_flagged_manual']:
                    summary['files_flagged_manual'].append(data['specie'])

        summary['n_files'] += 1
        if verdict == 'FAIL':
            summary['n_files_repaired'] += 1
        summary['n_repairs_total'] += len(repairs)
        summary['n_prose_edits_total'] += len(prose_edits)

        if write:
            with open(fp, 'w', encoding='utf-8') as fh:
                json.dump(data, fh, ensure_ascii=False, indent=2)
        else:
            # preview diffs
            print('\n=== %s  [%s, %d repairs] ===' % (sp, verdict, len(repairs)))
            for r in repairs:
                print('  (%s/%s)' % (r['repair_mode'], r['code']))
                print('     BEFORE: %s' % r['before'])
                print('     AFTER : %s' % r['after'])
            for pe in prose_edits:
                print('  PROSE_EDIT inserted %r' % pe['inserted'])

    summary['repairs_by_code'] = dict(summary['repairs_by_code'])
    if write:
        with open(os.path.join(root, 'repair_summary.json'), 'w',
                  encoding='utf-8') as fh:
            json.dump(summary, fh, ensure_ascii=False, indent=2)
    print('\n--- SUMMARY ---')
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    args = sys.argv[1:]
    write = '--write' in args
    pv = None
    root = HERE
    for a in args:
        if a.startswith('--preview='):
            pv = int(a.split('=')[1])
        elif a.startswith('--root='):
            root = os.path.abspath(a.split('=', 1)[1])
    main(preview_n=pv, write=write, root=root)
