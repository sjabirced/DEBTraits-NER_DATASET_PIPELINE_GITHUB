#!/usr/bin/env python3
"""
Final applier: produce corrected_text_final per file, occurrence/position-based.

For each Ri/N_R_i/F_R_i bracket (in document order):
  - auto-resolve via resolve.find_verbatim_span (respan / respan_event), OR
  - if flagged (partial/invented_tail/remove), consume the next matching manual
    override for that (species, original) and apply it (or delete if REMOVE).
Replacements are applied right-to-left by character offset so positions stay valid.
Repeated brackets are handled independently (one occurrence may PASS while another
is re-spanned).
"""
import json, os, sys, re
from collections import defaultdict, Counter
import reverify as R
import resolve as S
from pipeline import label_logic, prose_to_bracket, sentence_of

BR = re.compile(r'\[(?:Ri|N_R_i|F_R_i)\s*=\s*([^\]]*)\]')


def load_overrides(base):
    path = os.path.join(base, f'overrides_{os.path.basename(base)}.json')
    if not os.path.exists(path):
        return {}
    q = defaultdict(list)
    for ov in json.load(open(path)):
        q[(ov['species'], ov['original'])].append(ov['correction'])
    return q


def main():
    base = sys.argv[1]
    write = '--write' in sys.argv
    input_dir = os.path.join(base, 'with_errors')
    out_dir = os.path.join(base, 'corrected_final')
    if write:
        os.makedirs(out_dir, exist_ok=True)

    overrides = load_overrides(base)
    counts = Counter()
    review = {'respan_event': [], 'overrides': [], 'removes': []}
    unresolved = []

    for fn in sorted(f for f in os.listdir(input_dir) if f.endswith('.json')):
        item = json.load(open(os.path.join(input_dir, fn)))
        text = item['corrected_text']
        sp = item['specie']
        ov_queue = {k: list(v) for k, v in overrides.items() if k[0] == sp}

        edits = []   # (start, end, replacement)
        for m in R.BRACKET_RE.finditer(text):
            label, value = m.group(1), m.group(2).strip()
            original = m.group(0)
            pb = prose_to_bracket(text, m)
            sent = sentence_of(text, m)
            kind, res = S.find_verbatim_span(pb, value)

            if kind in ('respan', 'respan_event'):
                span = res if kind == 'respan' else res['span']
                new_label, _ = label_logic(label, span)
                corrected = f'[{new_label} = {span}]'
                counts[kind] += 1
                if corrected != original:
                    edits.append((m.start(), m.end(), corrected))
                    if kind == 'respan_event':
                        review['respan_event'].append(
                            {'species': sp, 'from': original, 'to': corrected,
                             'sentence': sent})
            else:
                # flagged -> consume override
                q = ov_queue.get((sp, original))
                if not q:
                    unresolved.append({'species': sp, 'original': original,
                                       'kind': kind, 'sentence': sent})
                    counts['UNRESOLVED'] += 1
                    continue
                corr = q.pop(0)
                counts['override'] += 1
                if corr == 'REMOVE':
                    # remove the bracket only; leave surrounding prose untouched
                    edits.append((m.start(), m.end(), ''))
                    review['removes'].append({'species': sp, 'removed': original,
                                              'sentence': sent})
                else:
                    edits.append((m.start(), m.end(), corr))
                    review['overrides'].append({'species': sp, 'from': original,
                                                'to': corr, 'sentence': sent})

        # apply edits right-to-left
        new_text = text
        for s, e, repl in sorted(edits, key=lambda x: x[0], reverse=True):
            new_text = new_text[:s] + repl + new_text[e:]
        item['corrected_text_final'] = new_text

        if write:
            json.dump(item, open(os.path.join(out_dir, fn), 'w'),
                      indent=2, ensure_ascii=False)

    print('=== build_corrected ===')
    for k, n in counts.most_common():
        print(f'  {k:14s}: {n}')
    print(f"\nReview: respan_event={len(review['respan_event'])} "
          f"overrides={len(review['overrides'])} removes={len(review['removes'])}")
    print(f"UNRESOLVED flags: {len(unresolved)}")
    if unresolved:
        for u in unresolved[:20]:
            print(f"  ! {u['species']} {u['original']}  | {u['sentence'][:90]}")

    json.dump(review, open(os.path.join(base, 'review_final.json'), 'w'),
              indent=2, ensure_ascii=False)
    json.dump(unresolved, open(os.path.join(base, 'unresolved.json'), 'w'),
              indent=2, ensure_ascii=False)
    print('\nWrote review_final.json, unresolved.json')
    if write:
        print(f'Wrote corrected files -> {out_dir}/')


if __name__ == '__main__':
    main()
