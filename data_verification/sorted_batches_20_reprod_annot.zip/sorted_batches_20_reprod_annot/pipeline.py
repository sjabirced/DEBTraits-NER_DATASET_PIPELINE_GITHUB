#!/usr/bin/env python3
"""
Integrated re-verification + correction pipeline (from prose, anchored).

For every Ri/N_R_i/F_R_i bracket:
  1. Build verbatim prose from sentence-start up to the bracket (other [..] tags stripped).
  2. Anchored re-span (resolve.find_verbatim_span) -> verbatim value or a judgment flag.
  3. Apply label logic (G1a / G1c / G1e) to the verbatim value.
  4. Emit corrected bracket, or flag for manual review.

Auto-applied: RESPAN (+ label relabels). Flagged: invented_tail / partial / remove.
Dry-run by default; pass --write to produce corrected files.
"""
import json, re, os, sys
from collections import Counter, defaultdict
import reverify as R
import resolve as S

TIME_UNITS = R.TIME_UNITS
EVENT_KEYWORDS = R.EVENT_KEYWORDS
OFFSPRING_WORDS = R.OFFSPRING_WORDS
EVENT_WORDS = R.EVENT_WORDS
PER_EVENT_EXPLICIT = ['per clutch','per litter','per nest','per brood','per spawning',
                      'per batch','per birth','per event','per pregnancy','per cocoon',
                      'per oviposition','per capsule','per nesting','per reproductive event']


def has_any(text, needles):
    low = text.lower()
    return any(re.search(r'\b' + re.escape(n) + r'\b', low) for n in needles)


def label_logic(label, value):
    """Return (new_label, code) applying G1a/G1c/G1e to a verbatim value."""
    has_time = has_any(value, TIME_UNITS)
    has_event_kw = any(k in value.lower() for k in PER_EVENT_EXPLICIT)
    has_off = has_any(value, OFFSPRING_WORDS)
    has_evt = has_any(value, EVENT_WORDS)
    if label == 'N_R_i' and has_time and not has_event_kw:
        return 'Ri', 'G1a'
    if label == 'Ri' and has_evt and has_time and not has_off:
        return 'F_R_i', 'G1c'
    if label == 'F_R_i' and has_off and has_time and not has_evt:
        return 'Ri', 'G1e'
    return label, None


def prose_to_bracket(text, bracket_match):
    """Verbatim prose from sentence start to bracket start, with [..] tags removed."""
    s, _ = R.sentence_bounds(text, bracket_match.start())
    chunk = text[s:bracket_match.start()]
    chunk = R.ANY_BRACKET_RE.sub('', chunk)   # drop any embedded annotation tags
    return chunk


def sentence_of(text, m):
    s, e = R.sentence_bounds(text, m.start())
    return R.norm(R.ANY_BRACKET_RE.sub('', text[s:e]))


def process_text(text):
    """Yield correction records for one corrected_text."""
    out = []
    for m in R.BRACKET_RE.finditer(text):
        label, value = m.group(1), m.group(2).strip()
        original = m.group(0)
        prose_before = prose_to_bracket(text, m)
        kind, res = S.find_verbatim_span(prose_before, value)

        rec = {'original': original, 'label': label, 'value': value, 'kind': kind,
               'sentence': sentence_of(text, m)}

        if kind in ('respan', 'respan_event'):
            span = res if kind == 'respan' else res['span']
            new_label, code = label_logic(label, span)
            corrected = f'[{new_label} = {span}]'
            rec.update(action='auto', corrected=corrected, kind=kind,
                       codes=[c for c in ([code] if code else []) +
                              (['SPAN'] if span != value else [])],
                       changed=(corrected != original),
                       review=(kind == 'respan_event'))
        else:
            rec.update(action='flag', corrected=None,
                       detail=res, changed=False)
        out.append(rec)
    return out


def main():
    base = sys.argv[1]
    write = '--write' in sys.argv
    input_dir = os.path.join(base, 'with_errors')
    out_dir = os.path.join(base, 'corrected_v2')
    if write:
        os.makedirs(out_dir, exist_ok=True)

    files = sorted(f for f in os.listdir(input_dir) if f.endswith('.json'))
    kind_counts = Counter()
    flag_list = []
    review_list = []
    change_log = []
    auto_changes = 0

    for fn in files:
        item = json.load(open(os.path.join(input_dir, fn)))
        text = item['corrected_text']
        recs = process_text(text)

        new_text = text
        sp_changes = []
        for rec in recs:
            kind_counts[rec['kind']] += 1
            if rec['action'] == 'auto' and rec['changed']:
                new_text = new_text.replace(rec['original'], rec['corrected'], 1)
                auto_changes += 1
                sp_changes.append({'from': rec['original'], 'to': rec['corrected'],
                                   'codes': rec['codes']})
                if rec.get('review'):   # respan_event: verbatim but spot-check
                    review_list.append({'species': item['specie'],
                                        'from': rec['original'], 'to': rec['corrected'],
                                        'sentence': rec['sentence']})
            elif rec['action'] == 'flag':
                flag_list.append({'file': fn, 'species': item['specie'],
                                  'original': rec['original'], 'kind': rec['kind'],
                                  'sentence': rec['sentence'],
                                  'detail': rec['detail']})

        change_log.append({'species': item['specie'], 'changes': sp_changes})
        if write:
            item['corrected_text_final'] = new_text
            json.dump(item, open(os.path.join(out_dir, fn), 'w'),
                      indent=2, ensure_ascii=False)

    print('=== Anchored pipeline (from prose) ===')
    for k, n in kind_counts.most_common():
        print(f'  {k:14s}: {n}')
    print(f'\nTotal brackets : {sum(kind_counts.values())}')
    print(f'Auto changes   : {auto_changes}')
    print(f'Flagged (judgment) : {len(flag_list)}')

    print(f'Respan_event (auto, spot-check) : {len(review_list)}')
    json.dump(flag_list, open(os.path.join(base, 'flags_v2.json'), 'w'),
              indent=2, ensure_ascii=False)
    json.dump(review_list, open(os.path.join(base, 'respan_event_review.json'), 'w'),
              indent=2, ensure_ascii=False)
    json.dump(change_log, open(os.path.join(base, 'change_log.json'), 'w'),
              indent=2, ensure_ascii=False)
    print('Wrote flags_v2.json, respan_event_review.json, change_log.json')
    if write:
        print(f'Wrote corrected files -> {out_dir}/')


if __name__ == '__main__':
    main()
